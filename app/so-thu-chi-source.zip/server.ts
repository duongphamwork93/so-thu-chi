import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '20mb' }));

// Initialize GoogleGenAI server-side with User-Agent
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Category list for reference in prompt
const CATEGORY_KEYS = [
  'an_uong', 'cho_sieu_thi', 'di_lai', 'nha_o',
  'con_sua_bim', 'giao_duc', 'con_do_dung', 'con_y_te',
  'suc_khoe', 'cafe', 'mua_sam', 'giai_tri',
  'hieu_hi', 'tiet_kiem', 'tra_no', 'khac',
  'luong', 'thuong', 'thu_phu', 'loi_dau_tu', 'bhxh', 'hoan_thue', 'duoc_tang', 'thu_khac'
];

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, hasKey: !!process.env.GEMINI_API_KEY });
});

app.get('/api/download/source', (_req, res) => {
  const filePath = path.resolve(__dirname, 'public', 'so-thu-chi-source.zip');
  res.download(filePath, 'so-thu-chi-source.zip');
});

app.get('/api/download/build', (_req, res) => {
  const filePath = path.resolve(__dirname, 'public', 'so-thu-chi-github-pages.zip');
  res.download(filePath, 'so-thu-chi-github-pages.zip');
});

// Endpoint đẩy code trực tiếp lên GitHub bằng Personal Access Token
app.post('/api/github/push', async (req, res) => {
  try {
    const {
      token,
      repoOwner = 'duongphamwork93',
      repoName = 'so-thu-chi',
      branch = 'main',
      commitMsg = 'Nâng cấp Sổ Thu Chi (React 19 + TypeScript + Tailwind + AI)',
    } = req.body;

    if (!token || !token.trim()) {
      return res.status(400).json({ error: 'Vui lòng nhập GitHub Personal Access Token (PAT).' });
    }

    const cleanToken = token.trim();
    const remoteUrl = `https://${cleanToken}@github.com/${repoOwner}/${repoName}.git`;

    const { exec } = await import('child_process');
    const { promisify } = await import('util');
    const execAsync = promisify(exec);

    // Build fresh static dist first
    try {
      await execAsync('npm run build', { cwd: __dirname });
    } catch (bErr) {
      console.warn('Build warning:', bErr);
    }

    const commands = [
      'git init',
      'git config user.name "duongphamwork93"',
      'git config user.email "duongpham.work93@gmail.com"',
      `git branch -M ${branch}`,
      'git add .',
      `git commit -m "${commitMsg.replace(/"/g, '\\"')}" || true`,
      `git push -u "${remoteUrl}" ${branch} --force`,
    ];

    let combinedOutput = '';
    for (const cmd of commands) {
      try {
        const { stdout, stderr } = await execAsync(cmd, { cwd: __dirname });
        combinedOutput += (stdout || '') + (stderr || '') + '\n';
      } catch (err: any) {
        const safeError = (err.message || '').replace(new RegExp(cleanToken, 'g'), '***TOKEN***');
        return res.status(500).json({ error: `Lỗi khi đẩy lên GitHub: ${safeError}` });
      }
    }

    return res.json({
      success: true,
      message: `Đã cập nhật thành công lên GitHub https://github.com/${repoOwner}/${repoName}!`,
      details: combinedOutput.replace(new RegExp(cleanToken, 'g'), '***'),
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Lỗi khi cập nhật lên GitHub' });
  }
});

// 1. Quét & bóc tách hóa đơn / sao kê ngân hàng qua ảnh hoặc văn bản
app.post('/api/gemini/parse-receipt', async (req, res) => {
  try {
    const { imageBase64, mimeType, rawText } = req.body;

    if (!process.env.GEMINI_API_KEY) {
      return res.status(400).json({ error: 'Chưa cấu hình GEMINI_API_KEY trong mục Secrets.' });
    }

    const parts: any[] = [];
    if (imageBase64) {
      parts.push({
        inlineData: {
          mimeType: mimeType || 'image/jpeg',
          data: imageBase64.replace(/^data:image\/[a-z]+;base64,/, ''),
        },
      });
    }

    const promptText = `Bạn là chuyên gia bóc tách hoá đơn, biên lai thanh toán, bill siêu thị, vé xe, và ảnh chụp màn hình chuyển khoản ngân hàng (VietinBank, VCB, MB, Techcombank, MoMo, ZaloPay,...) cho người Việt Nam.
Hãy đọc kỹ hình ảnh hoặc nội dung văn bản sau để trích xuất dữ liệu chi tiêu / thu nhập chính xác nhất có thể.

Danh mục khả dụng (chọn đúng một mã key phù hợp nhất):
- an_uong (Cơm, bún, phở, nhà hàng, quán ăn, GrabFood, ShopeeFood)
- cho_sieu_thi (WinMart, Co.opmart, Bách Hóa Xanh, Lotte, Aeon, đồ đi chợ tươi sống)
- di_lai (Xăng xe Petrolimex, Grab, Be, Xanh SM, VETC, vé máy bay, gửi xe)
- nha_o (Tiền thuê nhà, điện EVN, nước sinh hoạt, Internet FPT/VNPT/Viettel)
- con_sua_bim (Sữa bột, bỉm tã, Con Cưng, KidsPlaza, BiboMart, ăn dặm)
- giao_duc (Học phí, trường mầm non, sách vở, học tiếng Anh)
- con_do_dung (Quần áo trẻ em, đồ chơi cho bé)
- con_y_te (Khám nhi, tiêm chủng VNVC, thuốc cho bé)
- suc_khoe (Nhà thuốc Long Châu, Pharmacity, khám bệnh, bảo hiểm)
- cafe (Highlands, Phúc Long, Starbucks, trà sữa, quán cafe)
- mua_sam (Shopee, Lazada, TikTok Shop, quần áo, mỹ phẩm, điện tử)
- giai_tri (Xem phim CGV, du lịch, Netflix, Spotify, tiệc tùng)
- hieu_hi (Đám cưới, mừng tân gia, sinh nhật, phong bì, quà tặng)
- tiet_kiem (Gửi tiết kiệm, mua vàng tích lũy)
- tra_no (Trả nợ vay ngân hàng, thẻ tín dụng, trả góp)
- khac (Chi tiêu khác)
- luong (Lương nhận vào)
- thuong (Tiền thưởng)
- thu_phu (Làm thêm ngoài giờ, bán hàng online)
- loi_dau_tu (Lãi tiết kiệm, cổ tức, tiền lời)
- duoc_tang (Tiền lì xì, người khác biếu tặng)

Văn bản bổ sung nếu có: ${rawText || ''}`;

    parts.push({ text: promptText });

    const timeoutPromise = new Promise((_, reject) =>
      setTimeout(() => reject(new Error('Yêu cầu Gemini quá thời gian (timeout)')), 15000)
    );

    const callPromise = ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: { parts },
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            merchant: { type: Type.STRING, description: 'Tên cửa hàng, thương hiệu, hoặc người nhận tiền' },
            date: { type: Type.STRING, description: 'Ngày giao dịch định dạng YYYY-MM-DD' },
            amount: { type: Type.NUMBER, description: 'Tổng số tiền giao dịch thực tế (VNĐ, số nguyên dương)' },
            type: { type: Type.STRING, description: "'out' cho chi tiêu, 'in' cho thu nhập" },
            category: { type: Type.STRING, description: 'Mã category key tương ứng từ danh sách cung cấp' },
            note: { type: Type.STRING, description: 'Ghi chú tóm tắt nội dung giao dịch' },
            items: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  price: { type: Type.NUMBER },
                  qty: { type: Type.NUMBER },
                },
              },
              description: 'Danh sách món hàng hoặc dịch vụ nếu có chi tiết trong hoá đơn',
            },
          },
          required: ['merchant', 'amount', 'type', 'category', 'note'],
        },
      },
    });

    const response: any = await Promise.race([callPromise, timeoutPromise]);
    const parsed = JSON.parse(response.text || '{}');
    return res.json({ success: true, data: parsed });
  } catch (err: any) {
    console.error('Error parsing receipt:', err);
    return res.status(500).json({ error: err.message || 'Lỗi khi phân tích hoá đơn với Gemini' });
  }
});

// 2. Nhập nhanh câu lệnh tiếng Việt tự nhiên
app.post('/api/gemini/quick-text', async (req, res) => {
  try {
    const { text, currentDate } = req.body;
    if (!text) return res.status(400).json({ error: 'Text is required' });

    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({ error: 'GEMINI_API_KEY is not configured.' });
    }

    const todayStr = currentDate || new Date().toISOString().slice(0, 10);
    const prompt = `Hôm nay là ngày: ${todayStr}.
Người dùng nhập câu tiếng Việt nhanh để ghi sổ thu chi: "${text}".
Ví dụ:
- "ăn trưa bún chả 45k" => amount: 45000, type: "out", cat: "an_uong", note: "Ăn trưa bún chả"
- "đổ xăng 70k cây petrolimex bằng momo" => amount: 70000, type: "out", cat: "di_lai", note: "Đổ xăng cây petrolimex", account: "momo"
- "mua 2 hộp sữa bột meiji 1100k con cung" => amount: 1100000, type: "out", cat: "con_sua_bim", note: "Sữa bột meiji Con Cưng"
- "nhận lương 28 triệu về vcb" => amount: 28000000, type: "in", cat: "luong", note: "Lương tháng", account: "vietcombank"
- "hôm qua cà phê highland 65k" => date sẽ tính là ngày hôm qua (${todayStr} trừ 1 ngày).

Hãy bóc tách thành giao dịch chuẩn.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            amount: { type: Type.NUMBER, description: 'Số tiền bằng VNĐ (số dương)' },
            type: { type: Type.STRING, description: "'out' cho chi, 'in' cho thu" },
            category: { type: Type.STRING, description: 'Khóa danh mục phù hợp' },
            note: { type: Type.STRING, description: 'Tên ghi chú rõ ràng' },
            date: { type: Type.STRING, description: 'Ngày YYYY-MM-DD' },
            account: { type: Type.STRING, description: 'Tên tài khoản hoặc ví thanh toán nếu có nhắc đến' },
          },
          required: ['amount', 'type', 'category', 'note', 'date'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json({ success: true, data: parsed });
  } catch (err: any) {
    console.error('Error quick parse text:', err);
    return res.status(500).json({ error: err.message || 'Lỗi khi phân tích câu lệnh' });
  }
});

// 3. Phân tích tài chính cá nhân & đưa ra lời khuyên thông minh
app.post('/api/gemini/advisor', async (req, res) => {
  try {
    const { month, income, expense, byCategory, netWorth, debts, savings, budget } = req.body;

    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({ error: 'GEMINI_API_KEY is not configured.' });
    }

    const prompt = `Bạn là chuyên gia hoạch định tài chính cá nhân và gia đình giàu kinh nghiệm tại Việt Nam.
Dưới đây là bức tranh tài chính tháng ${month || 'gần đây'}:
- Tổng thu nhập: ${income?.toLocaleString('vi-VN')} ₫
- Tổng chi tiêu: ${expense?.toLocaleString('vi-VN')} ₫
- Hạn mức ngân sách tháng đã đặt: ${budget ? budget.toLocaleString('vi-VN') + ' ₫' : 'Chưa đặt'}
- Thặng dư/Tiết kiệm trong tháng: ${(income - expense)?.toLocaleString('vi-VN')} ₫
- Chi tiết theo danh mục: ${JSON.stringify(byCategory || {})}
- Tổng tài sản ròng (Net Worth): ${netWorth?.toLocaleString('vi-VN')} ₫
- Tổng nợ (vay nợ, thẻ tín dụng): ${debts?.toLocaleString('vi-VN')} ₫
- Tổng tiết kiệm & đầu tư: ${savings?.toLocaleString('vi-VN')} ₫

Hãy phân tích sức khỏe tài chính thực tế, chỉ ra điểm tích cực, những khoản chi có thể đang lãng phí hoặc vượt chuẩn 50/30/20, và đưa ra 3 lời khuyên cụ thể, hành động được ngay cho lối sống tại Việt Nam.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            financialHealthScore: { type: Type.NUMBER, description: 'Điểm sức khỏe tài chính từ 1 đến 100' },
            healthStatus: { type: Type.STRING, description: 'Đánh giá ngắn: Xuất sắc, Tốt, Cần lưu ý, Nguy cơ' },
            summary: { type: Type.STRING, description: 'Tóm tắt tình hình tài chính tháng' },
            rule503020: {
              type: Type.OBJECT,
              properties: {
                needPct: { type: Type.NUMBER, description: 'Tỷ lệ % chi thiết yếu' },
                wantPct: { type: Type.NUMBER, description: 'Tỷ lệ % chi theo sở thích cá nhân' },
                savePct: { type: Type.NUMBER, description: 'Tỷ lệ % tiết kiệm & đầu tư' },
                comment: { type: Type.STRING, description: 'Nhận xét về tỉ lệ 50/30/20' },
              },
              required: ['needPct', 'wantPct', 'savePct', 'comment'],
            },
            keyInsights: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  type: { type: Type.STRING, description: "'success' | 'warning' | 'tip'" },
                  description: { type: Type.STRING },
                },
                required: ['title', 'type', 'description'],
              },
            },
            actionSteps: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  detail: { type: Type.STRING },
                  estimatedSaving: { type: Type.STRING },
                },
                required: ['title', 'detail'],
              },
            },
          },
          required: ['financialHealthScore', 'healthStatus', 'summary', 'rule503020', 'keyInsights', 'actionSteps'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json({ success: true, data: parsed });
  } catch (err: any) {
    console.error('Error in financial advisor:', err);
    return res.status(500).json({ error: err.message || 'Lỗi khi phân tích tài chính với AI' });
  }
});

// Setup Vite middlewares in development or static files in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server is running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
