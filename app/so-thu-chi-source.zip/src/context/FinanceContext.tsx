import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  Account,
  AppSettings,
  CreditCard,
  DebtItem,
  InvestmentHolding,
  RecurringItem,
  SavingsDeposit,
  SavingsGoal,
  StorageData,
  Transaction,
} from '../types/finance';
import { getCurrentMonthString, getTodayDateString, shiftMonthString } from '../utils/formatters';

const STORAGE_KEY = 'sothuchi.v1';

export function getInitialDemoData(): StorageData {
  const curMonth = getCurrentMonthString();
  const d = (day: number) => `${curMonth}-${String(day).padStart(2, '0')}`;

  const defaultAccounts: Account[] = [
    { id: 'acc_vcb', name: 'Vietcombank (Lương chính)', type: 'bank', balance: 24500000, bankName: 'Vietcombank', color: '#10B981' },
    { id: 'acc_tcb', name: 'Techcombank (Sinh hoạt)', type: 'bank', balance: 8200000, bankName: 'Techcombank', color: '#EF4444' },
    { id: 'acc_momo', name: 'Ví MoMo', type: 'wallet', balance: 1450000, color: '#EC4899' },
    { id: 'acc_cash', name: 'Tiền mặt trong ví', type: 'cash', balance: 950000, color: '#F59E0B' },
  ];

  const defaultTransactions: Transaction[] = [
    { id: 'tx_1', type: 'in', cat: 'luong', amount: 28000000, date: d(5), note: 'Lương tháng nhận vào VCB', accountId: 'acc_vcb', createdAt: 1 },
    { id: 'tx_2', type: 'out', cat: 'nha_o', amount: 6500000, date: d(1), note: 'Tiền thuê căn hộ tháng này', accountId: 'acc_vcb', createdAt: 2 },
    { id: 'tx_3', type: 'out', cat: 'giao_duc', amount: 3500000, date: d(2), note: 'Học phí mầm non cho bé Bơ', accountId: 'acc_tcb', createdAt: 3 },
    { id: 'tx_4', type: 'out', cat: 'nha_o', amount: 820000, date: d(3), note: 'Hóa đơn tiền điện EVN + Internet', accountId: 'acc_tcb', createdAt: 4 },
    { id: 'tx_5', type: 'out', cat: 'cho_sieu_thi', amount: 1450000, date: d(4), note: 'Đi siêu thị Co.opmart mua đồ tuần', accountId: 'acc_tcb', createdAt: 5 },
    { id: 'tx_6', type: 'out', cat: 'tiet_kiem', amount: 3000000, date: d(5), note: 'Gửi tích lũy sổ tiết kiệm', accountId: 'acc_vcb', createdAt: 6 },
    { id: 'tx_7', type: 'out', cat: 'an_uong', amount: 65000, date: d(6), note: 'Cơm trưa văn phòng', accountId: 'acc_momo', createdAt: 7 },
    { id: 'tx_8', type: 'out', cat: 'cafe', amount: 59000, date: d(6), note: 'Highlands Coffee gặp bạn bè', accountId: 'acc_momo', createdAt: 8 },
    { id: 'tx_9', type: 'out', cat: 'con_sua_bim', amount: 1250000, date: d(7), note: 'Con Cưng – mua 2 hộp sữa bột và bỉm', accountId: 'acc_tcb', createdAt: 9 },
    { id: 'tx_10', type: 'out', cat: 'di_lai', amount: 180000, date: d(7), note: 'GrabCar đi gặp khách hàng', accountId: 'acc_momo', createdAt: 10 },
    { id: 'tx_11', type: 'out', cat: 'mua_sam', amount: 1290000, date: d(8), note: 'Shopee – giày chạy bộ & đồ gia dụng', accountId: 'acc_tcb', createdAt: 11 },
    { id: 'tx_12', type: 'out', cat: 'an_uong', amount: 420000, date: d(9), note: 'Lẩu nướng cuối tuần cả nhà', accountId: 'acc_momo', createdAt: 12 },
    { id: 'tx_13', type: 'out', cat: 'con_do_dung', amount: 320000, date: d(9), note: 'Đồ chơi xếp hình cho bé', accountId: 'acc_momo', createdAt: 13 },
    { id: 'tx_14', type: 'out', cat: 'con_y_te', amount: 450000, date: d(10), note: 'Khám nhi & tiêm phòng cúm', accountId: 'acc_tcb', createdAt: 14 },
    { id: 'tx_15', type: 'out', cat: 'cafe', amount: 45000, date: d(10), note: 'Phúc Long trà đào cam sả', accountId: 'acc_momo', createdAt: 15 },
    { id: 'tx_16', type: 'out', cat: 'hieu_hi', amount: 500000, date: d(11), note: 'Mừng đám cưới đồng nghiệp', accountId: 'acc_cash', createdAt: 16 },
  ];

  const defaultDeposits: SavingsDeposit[] = [
    {
      id: 'dep_1',
      bank: 'Vietcombank',
      amount: 100000000,
      termMonths: 6,
      interestRate: 5.2,
      startDate: `${shiftMonthString(curMonth, -3)}-15`,
      maturityDate: `${shiftMonthString(curMonth, 3)}-15`,
      rollover: 'all',
      note: 'Sổ tiết kiệm dự phòng',
    },
    {
      id: 'dep_2',
      bank: 'BIDV',
      amount: 150000000,
      termMonths: 12,
      interestRate: 5.8,
      startDate: `${shiftMonthString(curMonth, -8)}-10`,
      maturityDate: `${shiftMonthString(curMonth, 4)}-10`,
      rollover: 'principal',
      note: 'Tiết kiệm dài hạn gia đình',
    },
  ];

  const defaultHoldings: InvestmentHolding[] = [
    { id: 'inv_1', code: 'FPT', name: 'Cổ phiếu FPT Corp', type: 'stock', quantity: 500, buyPrice: 112000, currentPrice: 138000, note: 'Tích sản dài hạn' },
    { id: 'inv_2', code: 'DCDS', name: 'Quỹ Năng Động DC (Dragon Capital)', type: 'fund', quantity: 1200, buyPrice: 58000, currentPrice: 66500, note: 'Đầu tư định kỳ hằng tháng' },
    { id: 'inv_3', code: 'SJC9999', name: 'Vàng nhẫn trơn 999.9 (chỉ)', type: 'gold', quantity: 10, buyPrice: 7800000, currentPrice: 8850000, note: 'Mua tích trữ dần' },
  ];

  const defaultCards: CreditCard[] = [
    { id: 'card_1', name: 'HSBC Visa Platinum', bank: 'HSBC', limit: 50000000, currentBalance: 6200000, statementDay: 15, dueDay: 5, color: '#DC2626' },
  ];

  const defaultDebts: DebtItem[] = [
    { id: 'debt_1', dir: 'lend', name: 'Cho bạn Tuấn mượn', targetName: 'Lê Văn Tuấn', amount: 5000000, paidAmount: 2000000, dueDate: d(25), note: 'Hứa trả nốt cuối tháng' },
    { id: 'debt_2', dir: 'borrow', name: 'Vay trả góp mua máy lạnh', targetName: 'Home Credit', amount: 12000000, paidAmount: 8000000, dueDate: d(20), note: 'Kỳ 8/12 tháng' },
  ];

  const defaultGoals: SavingsGoal[] = [
    { id: 'goal_1', title: 'Quỹ dự phòng khẩn cấp 6 tháng', targetAmount: 120000000, currentAmount: 85000000, targetDate: '2026-12-31', color: '#10B981', icon: 'Shield' },
    { id: 'goal_2', title: 'Đổi xe máy gia đình', targetAmount: 45000000, currentAmount: 32000000, targetDate: '2026-10-30', color: '#3B82F6', icon: 'Bike' },
    { id: 'goal_3', title: 'Du lịch hè cả nhà', targetAmount: 20000000, currentAmount: 14500000, targetDate: '2026-07-15', color: '#F59E0B', icon: 'Palmtree' },
  ];

  const defaultRecs: RecurringItem[] = [
    { id: 'rec_1', type: 'out', name: 'Tiền thuê nhà', amount: 6500000, cat: 'nha_o', cycle: 'monthly', dayOfMonth: 1, accountId: 'acc_vcb' },
    { id: 'rec_2', type: 'out', name: 'Học phí mầm non của con', amount: 3500000, cat: 'giao_duc', cycle: 'monthly', dayOfMonth: 5, accountId: 'acc_tcb' },
    { id: 'rec_3', type: 'out', name: 'Điện lực EVN', amount: 800000, cat: 'nha_o', cycle: 'monthly', dayOfMonth: 10, accountId: 'acc_tcb' },
    { id: 'rec_4', type: 'out', name: 'Internet cáp quang Viettel', amount: 220000, cat: 'nha_o', cycle: 'monthly', dayOfMonth: 15, accountId: 'acc_tcb' },
    { id: 'rec_5', type: 'in', name: 'Lương cố định hằng tháng', amount: 28000000, cat: 'luong', cycle: 'monthly', dayOfMonth: 5, accountId: 'acc_vcb' },
  ];

  const defaultSettings: AppSettings = {
    budget: 20000000,
    goal: 'Tiết kiệm 30% thu nhập',
    risk: 'trung bình',
    privacyMask: false,
    theme: 'light',
    currency: 'VND',
  };

  return {
    records: defaultTransactions,
    settings: defaultSettings,
    advice: {},
    assets: [],
    debts: defaultDebts,
    goals: defaultGoals,
    recs: defaultRecs,
    cards: defaultCards,
    accts: defaultAccounts,
    xfers: [],
    deps: defaultDeposits,
    holds: defaultHoldings,
    nws: {},
  };
}

interface FinanceContextType {
  data: StorageData;
  currentMonth: string;
  setCurrentMonth: (month: string) => void;
  shiftMonth: (offset: number) => void;

  // Transactions
  addTransaction: (tx: Omit<Transaction, 'id' | 'createdAt'>) => Transaction;
  updateTransaction: (id: string, updates: Partial<Transaction>) => void;
  deleteTransaction: (id: string) => void;

  // Accounts
  addAccount: (acc: Omit<Account, 'id'>) => void;
  updateAccount: (id: string, updates: Partial<Account>) => void;
  deleteAccount: (id: string) => void;
  transferMoney: (fromAccId: string, toAccId: string, amount: number, note?: string) => void;

  // Savings deposits
  addDeposit: (dep: Omit<SavingsDeposit, 'id'>) => void;
  updateDeposit: (id: string, updates: Partial<SavingsDeposit>) => void;
  deleteDeposit: (id: string) => void;
  closeDeposit: (id: string, intoAccountId?: string) => void;

  // Investments
  addHolding: (h: Omit<InvestmentHolding, 'id'>) => void;
  updateHolding: (id: string, updates: Partial<InvestmentHolding>) => void;
  deleteHolding: (id: string) => void;

  // Cards
  addCreditCard: (card: Omit<CreditCard, 'id'>) => void;
  updateCreditCard: (id: string, updates: Partial<CreditCard>) => void;
  deleteCreditCard: (id: string) => void;
  payCreditCard: (cardId: string, fromAccountId: string, amount: number) => void;

  // Debts
  addDebt: (debt: Omit<DebtItem, 'id'>) => void;
  updateDebt: (id: string, updates: Partial<DebtItem>) => void;
  deleteDebt: (id: string) => void;
  recordDebtPayment: (debtId: string, amount: number, accountId?: string) => void;

  // Goals
  addGoal: (goal: Omit<SavingsGoal, 'id'>) => void;
  updateGoal: (id: string, updates: Partial<SavingsGoal>) => void;
  deleteGoal: (id: string) => void;
  contributeGoal: (goalId: string, amount: number, accountId?: string) => void;

  // Recurring
  addRecurring: (rec: Omit<RecurringItem, 'id'>) => void;
  updateRecurring: (id: string, updates: Partial<RecurringItem>) => void;
  deleteRecurring: (id: string) => void;
  recordRecurringNow: (recId: string) => void;

  // Settings & Utilities
  updateSettings: (updates: Partial<AppSettings>) => void;
  togglePrivacyMask: () => void;
  exportBackupJSON: () => void;
  importBackupJSON: (jsonString: string) => boolean;
  resetToSampleData: () => void;
}

const FinanceContext = createContext<FinanceContextType | undefined>(undefined);

export const FinanceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentMonth, setCurrentMonth] = useState<string>(() => getCurrentMonthString());
  const [data, setData] = useState<StorageData>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed && typeof parsed === 'object') {
          return {
            records: Array.isArray(parsed.records) ? parsed.records : [],
            settings: { ...getInitialDemoData().settings, ...(parsed.settings || {}) },
            advice: parsed.advice || {},
            assets: Array.isArray(parsed.assets) ? parsed.assets : [],
            debts: Array.isArray(parsed.debts) ? parsed.debts : [],
            goals: Array.isArray(parsed.goals) ? parsed.goals : [],
            recs: Array.isArray(parsed.recs) ? parsed.recs : [],
            cards: Array.isArray(parsed.cards) ? parsed.cards : [],
            accts: Array.isArray(parsed.accts) ? parsed.accts : [],
            xfers: Array.isArray(parsed.xfers) ? parsed.xfers : [],
            deps: Array.isArray(parsed.deps) ? parsed.deps : [],
            holds: Array.isArray(parsed.holds) ? parsed.holds : [],
            nws: parsed.nws || {},
          };
        }
      }
    } catch (e) {
      console.warn('Failed to parse localStorage data:', e);
    }
    return getInitialDemoData();
  });

  // Save to localStorage whenever data changes
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (e) {
      console.error('Error saving to localStorage:', e);
    }
  }, [data]);

  // Apply privacy mask class to document root
  useEffect(() => {
    if (data.settings.privacyMask) {
      document.documentElement.classList.add('privacy-mask');
    } else {
      document.documentElement.classList.remove('privacy-mask');
    }
  }, [data.settings.privacyMask]);

  // Shift month helper
  const shiftMonth = (offset: number) => {
    setCurrentMonth(prev => shiftMonthString(prev, offset));
  };

  // Transaction operations
  const addTransaction = (tx: Omit<Transaction, 'id' | 'createdAt'>): Transaction => {
    const newTx: Transaction = {
      ...tx,
      id: 'tx_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
      createdAt: Date.now(),
    };

    setData(prev => {
      // If linked to an account, adjust balance
      let nextAccts = [...prev.accts];
      if (tx.accountId) {
        nextAccts = nextAccts.map(acc => {
          if (acc.id === tx.accountId) {
            const diff = tx.type === 'in' ? tx.amount : -tx.amount;
            return { ...acc, balance: acc.balance + diff };
          }
          return acc;
        });
      }

      return {
        ...prev,
        records: [newTx, ...prev.records],
        accts: nextAccts,
      };
    });

    return newTx;
  };

  const updateTransaction = (id: string, updates: Partial<Transaction>) => {
    setData(prev => {
      const oldTx = prev.records.find(r => r.id === id);
      if (!oldTx) return prev;

      let nextAccts = [...prev.accts];

      // Revert old effect and apply new effect if account/amount/type changed
      const oldAccountId = oldTx.accountId;
      const newAccountId = updates.accountId !== undefined ? updates.accountId : oldAccountId;
      const oldAmount = oldTx.amount;
      const newAmount = updates.amount !== undefined ? updates.amount : oldAmount;
      const oldType = oldTx.type;
      const newType = updates.type !== undefined ? updates.type : oldType;

      if (oldAccountId) {
        nextAccts = nextAccts.map(a => {
          if (a.id === oldAccountId) {
            const revert = oldType === 'in' ? -oldAmount : oldAmount;
            return { ...a, balance: a.balance + revert };
          }
          return a;
        });
      }

      if (newAccountId) {
        nextAccts = nextAccts.map(a => {
          if (a.id === newAccountId) {
            const apply = newType === 'in' ? newAmount : -newAmount;
            return { ...a, balance: a.balance + apply };
          }
          return a;
        });
      }

      return {
        ...prev,
        records: prev.records.map(r => (r.id === id ? { ...r, ...updates } : r)),
        accts: nextAccts,
      };
    });
  };

  const deleteTransaction = (id: string) => {
    setData(prev => {
      const oldTx = prev.records.find(r => r.id === id);
      let nextAccts = [...prev.accts];
      if (oldTx && oldTx.accountId) {
        nextAccts = nextAccts.map(a => {
          if (a.id === oldTx.accountId) {
            const revert = oldTx.type === 'in' ? -oldTx.amount : oldTx.amount;
            return { ...a, balance: a.balance + revert };
          }
          return a;
        });
      }

      return {
        ...prev,
        records: prev.records.filter(r => r.id !== id),
        accts: nextAccts,
      };
    });
  };

  // Account operations
  const addAccount = (acc: Omit<Account, 'id'>) => {
    const newAcc: Account = {
      ...acc,
      id: 'acc_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
    };
    setData(prev => ({ ...prev, accts: [...prev.accts, newAcc] }));
  };

  const updateAccount = (id: string, updates: Partial<Account>) => {
    setData(prev => ({
      ...prev,
      accts: prev.accts.map(a => (a.id === id ? { ...a, ...updates } : a)),
    }));
  };

  const deleteAccount = (id: string) => {
    setData(prev => ({
      ...prev,
      accts: prev.accts.filter(a => a.id !== id),
    }));
  };

  const transferMoney = (fromAccId: string, toAccId: string, amount: number, note?: string) => {
    if (fromAccId === toAccId || amount <= 0) return;
    setData(prev => {
      const fromAcc = prev.accts.find(a => a.id === fromAccId);
      const toAcc = prev.accts.find(a => a.id === toAccId);
      if (!fromAcc || !toAcc) return prev;

      const nextAccts = prev.accts.map(a => {
        if (a.id === fromAccId) return { ...a, balance: a.balance - amount };
        if (a.id === toAccId) return { ...a, balance: a.balance + amount };
        return a;
      });

      const xferRecord = {
        id: 'xfer_' + Date.now().toString(36),
        fromId: fromAccId,
        toId: toAccId,
        amount,
        note: note || `Chuyển từ ${fromAcc.name} sang ${toAcc.name}`,
        date: getTodayDateString(),
      };

      return {
        ...prev,
        accts: nextAccts,
        xfers: [xferRecord, ...(prev.xfers || [])],
      };
    });
  };

  // Savings deposits
  const addDeposit = (dep: Omit<SavingsDeposit, 'id'>) => {
    const newDep: SavingsDeposit = {
      ...dep,
      id: 'dep_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
    };
    setData(prev => ({ ...prev, deps: [...prev.deps, newDep] }));
  };

  const updateDeposit = (id: string, updates: Partial<SavingsDeposit>) => {
    setData(prev => ({
      ...prev,
      deps: prev.deps.map(d => (d.id === id ? { ...d, ...updates } : d)),
    }));
  };

  const deleteDeposit = (id: string) => {
    setData(prev => ({
      ...prev,
      deps: prev.deps.filter(d => d.id !== id),
    }));
  };

  const closeDeposit = (id: string, intoAccountId?: string) => {
    setData(prev => {
      const dep = prev.deps.find(d => d.id === id);
      if (!dep || dep.closed) return prev;

      let nextAccts = [...prev.accts];
      // If user chose to return money to a bank account
      if (intoAccountId) {
        nextAccts = nextAccts.map(a => {
          if (a.id === intoAccountId) {
            return { ...a, balance: a.balance + dep.amount };
          }
          return a;
        });
      }

      return {
        ...prev,
        deps: prev.deps.map(d => (d.id === id ? { ...d, closed: true } : d)),
        accts: nextAccts,
      };
    });
  };

  // Investments
  const addHolding = (h: Omit<InvestmentHolding, 'id'>) => {
    const newH: InvestmentHolding = {
      ...h,
      id: 'inv_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
    };
    setData(prev => ({ ...prev, holds: [...prev.holds, newH] }));
  };

  const updateHolding = (id: string, updates: Partial<InvestmentHolding>) => {
    setData(prev => ({
      ...prev,
      holds: prev.holds.map(h => (h.id === id ? { ...h, ...updates } : h)),
    }));
  };

  const deleteHolding = (id: string) => {
    setData(prev => ({
      ...prev,
      holds: prev.holds.filter(h => h.id !== id),
    }));
  };

  // Credit cards
  const addCreditCard = (card: Omit<CreditCard, 'id'>) => {
    const newCard: CreditCard = {
      ...card,
      id: 'card_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
    };
    setData(prev => ({ ...prev, cards: [...prev.cards, newCard] }));
  };

  const updateCreditCard = (id: string, updates: Partial<CreditCard>) => {
    setData(prev => ({
      ...prev,
      cards: prev.cards.map(c => (c.id === id ? { ...c, ...updates } : c)),
    }));
  };

  const deleteCreditCard = (id: string) => {
    setData(prev => ({
      ...prev,
      cards: prev.cards.filter(c => c.id !== id),
    }));
  };

  const payCreditCard = (cardId: string, fromAccountId: string, amount: number) => {
    if (amount <= 0) return;
    setData(prev => {
      const card = prev.cards.find(c => c.id === cardId);
      if (!card) return prev;

      const nextCards = prev.cards.map(c => {
        if (c.id === cardId) {
          return { ...c, currentBalance: Math.max(0, c.currentBalance - amount) };
        }
        return c;
      });

      const nextAccts = prev.accts.map(a => {
        if (a.id === fromAccountId) {
          return { ...a, balance: a.balance - amount };
        }
        return a;
      });

      // Also record as a payment transaction
      const payTx: Transaction = {
        id: 'tx_pay_' + Date.now().toString(36),
        type: 'out',
        cat: 'tra_no',
        amount,
        date: getTodayDateString(),
        note: `Thanh toán dư nợ thẻ ${card.name}`,
        accountId: fromAccountId,
        createdAt: Date.now(),
      };

      return {
        ...prev,
        cards: nextCards,
        accts: nextAccts,
        records: [payTx, ...prev.records],
      };
    });
  };

  // Debts
  const addDebt = (debt: Omit<DebtItem, 'id'>) => {
    const newDebt: DebtItem = {
      ...debt,
      id: 'debt_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
    };
    setData(prev => ({ ...prev, debts: [...prev.debts, newDebt] }));
  };

  const updateDebt = (id: string, updates: Partial<DebtItem>) => {
    setData(prev => ({
      ...prev,
      debts: prev.debts.map(d => (d.id === id ? { ...d, ...updates } : d)),
    }));
  };

  const deleteDebt = (id: string) => {
    setData(prev => ({
      ...prev,
      debts: prev.debts.filter(d => d.id !== id),
    }));
  };

  const recordDebtPayment = (debtId: string, amount: number, accountId?: string) => {
    if (amount <= 0) return;
    setData(prev => {
      const debt = prev.debts.find(d => d.id === debtId);
      if (!debt) return prev;

      const newPaid = (debt.paidAmount || 0) + amount;
      const isClosed = newPaid >= debt.amount;

      const nextDebts = prev.debts.map(d => {
        if (d.id === debtId) {
          return { ...d, paidAmount: newPaid, closed: isClosed };
        }
        return d;
      });

      let nextAccts = [...prev.accts];
      let nextRecords = [...prev.records];

      // If debt was lend (someone pays back to us -> money In)
      // If debt was borrow (we pay them back -> money Out)
      if (accountId) {
        const isLend = debt.dir === 'lend';
        nextAccts = nextAccts.map(a => {
          if (a.id === accountId) {
            return { ...a, balance: a.balance + (isLend ? amount : -amount) };
          }
          return a;
        });

        nextRecords = [
          {
            id: 'tx_debt_' + Date.now().toString(36),
            type: isLend ? 'in' : 'out',
            cat: isLend ? 'thu_khac' : 'tra_no',
            amount,
            date: getTodayDateString(),
            note: isLend ? `Thu hồi nợ từ ${debt.targetName}` : `Trả nợ cho ${debt.targetName}`,
            accountId,
            createdAt: Date.now(),
          },
          ...nextRecords,
        ];
      }

      return {
        ...prev,
        debts: nextDebts,
        accts: nextAccts,
        records: nextRecords,
      };
    });
  };

  // Goals
  const addGoal = (goal: Omit<SavingsGoal, 'id'>) => {
    const newGoal: SavingsGoal = {
      ...goal,
      id: 'goal_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
    };
    setData(prev => ({ ...prev, goals: [...prev.goals, newGoal] }));
  };

  const updateGoal = (id: string, updates: Partial<SavingsGoal>) => {
    setData(prev => ({
      ...prev,
      goals: prev.goals.map(g => (g.id === id ? { ...g, ...updates } : g)),
    }));
  };

  const deleteGoal = (id: string) => {
    setData(prev => ({
      ...prev,
      goals: prev.goals.filter(g => g.id !== id),
    }));
  };

  const contributeGoal = (goalId: string, amount: number, accountId?: string) => {
    if (amount <= 0) return;
    setData(prev => {
      const goal = prev.goals.find(g => g.id === goalId);
      if (!goal) return prev;

      const nextGoals = prev.goals.map(g => {
        if (g.id === goalId) {
          return { ...g, currentAmount: g.currentAmount + amount };
        }
        return g;
      });

      let nextAccts = [...prev.accts];
      let nextRecords = [...prev.records];

      if (accountId) {
        nextAccts = nextAccts.map(a => {
          if (a.id === accountId) {
            return { ...a, balance: a.balance - amount };
          }
          return a;
        });

        nextRecords = [
          {
            id: 'tx_goal_' + Date.now().toString(36),
            type: 'out',
            cat: 'tiet_kiem',
            amount,
            date: getTodayDateString(),
            note: `Góp mục tiêu: ${goal.title}`,
            accountId,
            createdAt: Date.now(),
          },
          ...nextRecords,
        ];
      }

      return {
        ...prev,
        goals: nextGoals,
        accts: nextAccts,
        records: nextRecords,
      };
    });
  };

  // Recurring
  const addRecurring = (rec: Omit<RecurringItem, 'id'>) => {
    const newRec: RecurringItem = {
      ...rec,
      id: 'rec_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
    };
    setData(prev => ({ ...prev, recs: [...prev.recs, newRec] }));
  };

  const updateRecurring = (id: string, updates: Partial<RecurringItem>) => {
    setData(prev => ({
      ...prev,
      recs: prev.recs.map(r => (r.id === id ? { ...r, ...updates } : r)),
    }));
  };

  const deleteRecurring = (id: string) => {
    setData(prev => ({
      ...prev,
      recs: prev.recs.filter(r => r.id !== id),
    }));
  };

  const recordRecurringNow = (recId: string) => {
    const rec = data.recs.find(r => r.id === recId);
    if (!rec) return;

    addTransaction({
      type: rec.type,
      cat: rec.cat,
      amount: rec.amount,
      date: getTodayDateString(),
      note: `Khoản định kỳ: ${rec.name}`,
      accountId: rec.accountId,
    });

    updateRecurring(recId, { lastRecorded: getTodayDateString() });
  };

  // Settings
  const updateSettings = (updates: Partial<AppSettings>) => {
    setData(prev => ({
      ...prev,
      settings: { ...prev.settings, ...updates },
    }));
  };

  const togglePrivacyMask = () => {
    updateSettings({ privacyMask: !data.settings.privacyMask });
  };

  // Backup & Restore
  const exportBackupJSON = () => {
    try {
      const jsonStr = JSON.stringify(data, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
      a.href = url;
      a.download = `sothuchi_backup_${timestamp}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('Failed to export backup JSON:', e);
    }
  };

  const importBackupJSON = (jsonString: string): boolean => {
    try {
      const parsed = JSON.parse(jsonString);
      if (!parsed || typeof parsed !== 'object') return false;

      const validData: StorageData = {
        records: Array.isArray(parsed.records) ? parsed.records : [],
        settings: { ...getInitialDemoData().settings, ...(parsed.settings || {}) },
        advice: parsed.advice || {},
        assets: Array.isArray(parsed.assets) ? parsed.assets : [],
        debts: Array.isArray(parsed.debts) ? parsed.debts : [],
        goals: Array.isArray(parsed.goals) ? parsed.goals : [],
        recs: Array.isArray(parsed.recs) ? parsed.recs : [],
        cards: Array.isArray(parsed.cards) ? parsed.cards : [],
        accts: Array.isArray(parsed.accts) ? parsed.accts : [],
        xfers: Array.isArray(parsed.xfers) ? parsed.xfers : [],
        deps: Array.isArray(parsed.deps) ? parsed.deps : [],
        holds: Array.isArray(parsed.holds) ? parsed.holds : [],
        nws: parsed.nws || {},
      };

      setData(validData);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(validData));
      return true;
    } catch (e) {
      console.error('Invalid backup file JSON:', e);
      return false;
    }
  };

  const resetToSampleData = () => {
    const fresh = getInitialDemoData();
    setData(fresh);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(fresh));
  };

  return (
    <FinanceContext.Provider
      value={{
        data,
        currentMonth,
        setCurrentMonth,
        shiftMonth,
        addTransaction,
        updateTransaction,
        deleteTransaction,
        addAccount,
        updateAccount,
        deleteAccount,
        transferMoney,
        addDeposit,
        updateDeposit,
        deleteDeposit,
        closeDeposit,
        addHolding,
        updateHolding,
        deleteHolding,
        addCreditCard,
        updateCreditCard,
        deleteCreditCard,
        payCreditCard,
        addDebt,
        updateDebt,
        deleteDebt,
        recordDebtPayment,
        addGoal,
        updateGoal,
        deleteGoal,
        contributeGoal,
        addRecurring,
        updateRecurring,
        deleteRecurring,
        recordRecurringNow,
        updateSettings,
        togglePrivacyMask,
        exportBackupJSON,
        importBackupJSON,
        resetToSampleData,
      }}
    >
      {children}
    </FinanceContext.Provider>
  );
};

export const useFinance = () => {
  const context = useContext(FinanceContext);
  if (!context) {
    throw new Error('useFinance must be used within a FinanceProvider');
  }
  return context;
};
