export interface CategoryInfo {
  key: string;
  name: string;
  shortName: string;
  color: string;
  group: 'need' | 'want' | 'save' | 'income';
  section: string;
  isKid?: boolean;
  iconName: string;
}

export const EXPENSE_CATEGORIES: CategoryInfo[] = [
  // Sinh hoạt (Thiết yếu 50%)
  { key: 'an_uong', name: 'Ăn uống', shortName: 'Ăn uống', color: '#EA580C', group: 'need', section: 'Sinh hoạt', iconName: 'Utensils' },
  { key: 'cho_sieu_thi', name: 'Chợ, siêu thị', shortName: 'Siêu thị', color: '#D97706', group: 'need', section: 'Sinh hoạt', iconName: 'ShoppingCart' },
  { key: 'di_lai', name: 'Đi lại, xăng xe', shortName: 'Đi lại', color: '#2563EB', group: 'need', section: 'Sinh hoạt', iconName: 'Car' },
  { key: 'nha_o', name: 'Nhà ở, điện nước', shortName: 'Nhà ở', color: '#4F46E5', group: 'need', section: 'Sinh hoạt', iconName: 'Home' },

  // Con nhỏ (Thiết yếu & Chăm sóc)
  { key: 'con_sua_bim', name: 'Sữa, bỉm, đồ ăn bé', shortName: 'Sữa, bỉm', color: '#EC4899', group: 'need', section: 'Con nhỏ', isKid: true, iconName: 'Baby' },
  { key: 'giao_duc', name: 'Học phí, trường lớp', shortName: 'Học phí', color: '#16A34A', group: 'need', section: 'Con nhỏ', isKid: true, iconName: 'GraduationCap' },
  { key: 'con_do_dung', name: 'Quần áo, đồ chơi bé', shortName: 'Đồ dùng bé', color: '#F59E0B', group: 'want', section: 'Con nhỏ', isKid: true, iconName: 'ToyBrick' },
  { key: 'con_y_te', name: 'Khám bệnh, tiêm chủng', shortName: 'Y tế bé', color: '#0891B2', group: 'need', section: 'Con nhỏ', isKid: true, iconName: 'Stethoscope' },

  // Cá nhân
  { key: 'suc_khoe', name: 'Sức khoẻ, bảo hiểm', shortName: 'Sức khoẻ', color: '#0D9488', group: 'need', section: 'Cá nhân', iconName: 'HeartPulse' },
  { key: 'cafe', name: 'Cà phê, trà sữa', shortName: 'Cà phê', color: '#854D0E', group: 'want', section: 'Cá nhân', iconName: 'Coffee' },
  { key: 'mua_sam', name: 'Mua sắm cá nhân', shortName: 'Mua sắm', color: '#DB2777', group: 'want', section: 'Cá nhân', iconName: 'ShoppingBag' },
  { key: 'giai_tri', name: 'Giải trí, du lịch', shortName: 'Giải trí', color: '#9333EA', group: 'want', section: 'Cá nhân', iconName: 'Tv' },

  // Tài chính & Khác
  { key: 'hieu_hi', name: 'Hiếu hỉ, quà tặng', shortName: 'Hiếu hỉ', color: '#E11D48', group: 'want', section: 'Tài chính và khác', iconName: 'Gift' },
  { key: 'tiet_kiem', name: 'Tiết kiệm, đầu tư', shortName: 'Tiết kiệm', color: '#059669', group: 'save', section: 'Tài chính và khác', iconName: 'PiggyBank' },
  { key: 'tra_no', name: 'Trả nợ, trả góp', shortName: 'Trả nợ', color: '#DC2626', group: 'need', section: 'Tài chính và khác', iconName: 'CreditCard' },
  { key: 'khac', name: 'Chi tiêu khác', shortName: 'Khác', color: '#64748B', group: 'want', section: 'Tài chính và khác', iconName: 'CircleEllipsis' },
];

export const INCOME_CATEGORIES: CategoryInfo[] = [
  { key: 'luong', name: 'Lương chính', shortName: 'Lương', color: '#16A34A', group: 'income', section: 'Thu nhập', iconName: 'Briefcase' },
  { key: 'thuong', name: 'Thưởng lễ, Tết, KPI', shortName: 'Thưởng', color: '#D97706', group: 'income', section: 'Thu nhập', iconName: 'Award' },
  { key: 'thu_phu', name: 'Làm thêm, bán hàng', shortName: 'Làm thêm', color: '#2563EB', group: 'income', section: 'Thu nhập', iconName: 'Laptop' },
  { key: 'loi_dau_tu', name: 'Lãi tiết kiệm, cổ tức', shortName: 'Lãi đầu tư', color: '#059669', group: 'income', section: 'Thu nhập', iconName: 'TrendingUp' },
  { key: 'bhxh', name: 'Trợ cấp BHXH, thai sản', shortName: 'BHXH', color: '#0D9488', group: 'income', section: 'Thu nhập', iconName: 'ShieldCheck' },
  { key: 'hoan_thue', name: 'Hoàn thuế TNCN', shortName: 'Hoàn thuế', color: '#4F46E5', group: 'income', section: 'Thu nhập', iconName: 'Receipt' },
  { key: 'duoc_tang', name: 'Được tặng, lì xì', shortName: 'Quà, lì xì', color: '#E11D48', group: 'income', section: 'Thu nhập', iconName: 'Sparkles' },
  { key: 'thu_khac', name: 'Thu nhập khác', shortName: 'Thu khác', color: '#64748B', group: 'income', section: 'Thu nhập', iconName: 'Coins' },
];

export const ALL_CATEGORIES = [...EXPENSE_CATEGORIES, ...INCOME_CATEGORIES];
export const CATEGORY_MAP = Object.fromEntries(ALL_CATEGORIES.map(c => [c.key, c]));

// Vietnamese keyword rules for matching
export const KEYWORD_RULES: [string, string[]][] = [
  ['con_sua_bim', ['con cung', 'kids plaza', 'kidsplaza', 'bibo mart', 'bibomart', 'sua bot', 'sua tuoi', 'ta dan', 'ta quan', 'bim ', 'friso', 'similac', 'enfa', 'aptamil', 'meiji', 'nan optipro', 'an dam']],
  ['con_y_te', ['vnvc', 'tiem chung', 'vac xin', 'vaccine', 'nhi dong', 'benh vien nhi', 'phong kham nhi', 'kham nhi']],
  ['giao_duc', ['hoc phi', 'mam non', 'tieu hoc', 'truong mam', 'anh ngu', 'hoc them', 'nang khieu', 'sach vo', 'dung cu hoc tap']],
  ['cafe', ['highlands', 'phuc long', 'starbucks', 'the coffee house', 'coffee house', 'katinat', 'trung nguyen', 'cong caphe', 'cafe', 'ca phe', 'coffee', 'tra sua', 'gong cha', 'tocotoco', 'koi the', 'phe la', 'milk tea', 'tra dao']],
  ['an_uong', ['grabfood', 'grab food', 'shopeefood', 'shopee food', 'baemin', 'befood', 'kfc', 'lotteria', 'jollibee', 'mcdonald', 'pizza', 'nha hang', 'quan an', 'com tam', 'com ga', 'pho ', 'bun ', 'lau ', 'buffet', 'haidilao', 'gogi', 'manwah', 'banh mi', 'an sang', 'an trua', 'an toi']],
  ['di_lai', ['grabbike', 'grabcar', 'grab bike', 'grab car', 'xanh sm', 'petrolimex', 'xang dau', 'xang ', 'pvoil', 'vetc', 'epass', 'gui xe', 'vietjet', 'vietnam airlines', 'bamboo airways', 'grab', 'be ', 'taxi']],
  ['cho_sieu_thi', ['co.opmart', 'coopmart', 'co.op', 'winmart', 'vinmart', 'bach hoa xanh', 'lotte mart', 'aeon', 'big c', 'go! ', 'emart', 'mm mega', 'circle k', 'familymart', '7-eleven', 'ministop', 'gs25', 'sieu thi', 'cho dau moi', 'di cho', 'rau cu', 'thit ca']],
  ['suc_khoe', ['long chau', 'pharmacity', 'an khang', 'nha thuoc', 'benh vien', 'phong kham', 'medlatec', 'hoan my', 'vinmec', 'bao hiem', 'thuoc men', 'nha khoa', 'kham rang']],
  ['nha_o', ['evn', 'dien luc', 'tien dien', 'cap nuoc', 'tien nuoc', 'fpt telecom', 'vnpt', 'viettel', 'internet', 'tien nha', 'phi quan ly', 'gui xe toa nha', 'thue nha']],
  ['mua_sam', ['shopee', 'lazada', 'tiki', 'tiktok shop', 'uniqlo', 'zara', 'the gioi di dong', 'dien may xanh', 'fpt shop', 'cellphones', 'guardian', 'watsons', 'quan ao', 'giay dep', 'my pham']],
  ['giai_tri', ['cgv', 'lotte cinema', 'galaxy', 'bhd', 'netflix', 'spotify', 'youtube', 'vinwonders', 'khach san', 'agoda', 'booking.com', 'traveloka', 've xem phim', 'du lich']],
  ['hieu_hi', ['dam cuoi', 'mung cuoi', 'phung vieng', 'qua tang', 'sinh nhat', 'mung tho', 'phong bi']],
  ['tra_no', ['tra no', 'tra gop', 'fe credit', 'home credit', 'tra the', 'du no']],
  ['tiet_kiem', ['gui tiet kiem', 'mua vang', 'tich luy', 'gui ngan hang']],
  ['luong', ['luong', 'salary', 'nhan luong', 'cong ty chuyen khoan']],
  ['thuong', ['thuong', 'bonus', 'kpi', 'thuong tet', 'thuong le']],
  ['loi_dau_tu', ['co tuc', 'tien lai', 'lai tiet kiem', 'chot loi']],
  ['duoc_tang', ['li xi', 'lì xì', 'bieu tang', 'tang tien', 'mung tuoi']],
];

export function removeVietnameseAccents(str: string): string {
  return str
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D')
    .toLowerCase();
}

export function guessCategoryByText(text: string): string {
  const normalized = ' ' + removeVietnameseAccents(text).replace(/\s+/g, ' ') + ' ';
  for (const [catKey, keywords] of KEYWORD_RULES) {
    if (keywords.some(kw => normalized.includes(kw))) {
      return catKey;
    }
  }
  return 'khac';
}
