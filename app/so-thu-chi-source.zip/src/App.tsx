import React, { useState } from 'react';
import { FinanceProvider, useFinance } from './context/FinanceContext';
import { Header } from './components/Header';
import { Navigation, TabKey } from './components/Navigation';
import { OverviewView } from './components/views/OverviewView';
import { LedgerView } from './components/views/LedgerView';
import { AssetsView } from './components/views/AssetsView';
import { AIAdvisorView } from './components/views/AIAdvisorView';
import { SettingsView } from './components/views/SettingsView';
import { AddTransactionModal } from './components/modals/AddTransactionModal';
import { TransferModal } from './components/modals/TransferModal';
import { AddAssetModal, AssetCategoryType } from './components/modals/AddAssetModal';
import { GitHubPushModal } from './components/modals/GitHubPushModal';

const MainApp: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabKey>('home');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [isGitHubModalOpen, setIsGitHubModalOpen] = useState(false);
  const [assetModalCategory, setAssetModalCategory] = useState<AssetCategoryType | null>(null);

  const handleOpenAddAsset = (cat: AssetCategoryType) => {
    setAssetModalCategory(cat);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col transition-colors selection:bg-emerald-500 selection:text-white">
      {/* Top sticky header */}
      <Header
        onOpenQuickScan={() => setActiveTab('ai')}
        onOpenQuickAdd={() => setIsAddModalOpen(true)}
        onOpenGitHubModal={() => setIsGitHubModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-4 pt-4 pb-20">
        {activeTab === 'home' && (
          <OverviewView
            onNavigateTab={tab => setActiveTab(tab)}
            onOpenAddModal={() => setIsAddModalOpen(true)}
          />
        )}
        {activeTab === 'ledger' && (
          <LedgerView onOpenAddModal={() => setIsAddModalOpen(true)} />
        )}
        {activeTab === 'assets' && (
          <AssetsView
            onOpenAddAsset={handleOpenAddAsset}
            onOpenTransfer={() => setIsTransferModalOpen(true)}
          />
        )}
        {activeTab === 'ai' && <AIAdvisorView />}
        {activeTab === 'settings' && <SettingsView />}
      </main>

      {/* Bottom Tab Navigation */}
      <Navigation
        activeTab={activeTab}
        onTabChange={tab => setActiveTab(tab)}
        onOpenAddModal={() => setIsAddModalOpen(true)}
      />

      {/* Modals */}
      <AddTransactionModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
      />

      <TransferModal
        isOpen={isTransferModalOpen}
        onClose={() => setIsTransferModalOpen(false)}
      />

      <AddAssetModal
        isOpen={assetModalCategory !== null}
        onClose={() => setAssetModalCategory(null)}
        initialCategory={assetModalCategory || 'account'}
      />

      <GitHubPushModal
        isOpen={isGitHubModalOpen}
        onClose={() => setIsGitHubModalOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <FinanceProvider>
      <MainApp />
    </FinanceProvider>
  );
}
