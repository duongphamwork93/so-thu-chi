import React, { useState } from 'react';
import { X, Sparkles, Check, Calendar, CreditCard, FileText, ArrowDownLeft, ArrowUpRight } from 'lucide-react';
import { useFinance } from '../../context/FinanceContext';
import { EXPENSE_CATEGORIES, INCOME_CATEGORIES, guessCategoryByText } from '../../constants/categories';
import { CategoryIcon } from '../CategoryIcon';
import { formatVND, getTodayDateString, parseVietnameseMoneyText } from '../../utils/formatters';
import { TransactionType } from '../../types/finance';

interface AddTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialType?: TransactionType;
}

export const AddTransactionModal: React.FC<AddTransactionModalProps> = ({
  isOpen,
  onClose,
  initialType = 'out',
}) => {
  const { addTransaction, data } = useFinance();

  const [type, setType] = useState<TransactionType>(initialType);
  const [amountStr, setAmountStr] = useState<string>('');
  const [selectedCat, setSelectedCat] = useState<string>(type === 'out' ? 'an_uong' : 'luong');
  const [selectedAccount, setSelectedAccount] = useState<string>(data.accts[0]?.id || '');
  const [date, setDate] = useState<string>(getTodayDateString());
  const [note, setNote] = useState<string>('');

  // Quick text input
  const [quickInput, setQuickInput] = useState<string>('');
  const [isParsingQuick, setIsParsingQuick] = useState<boolean>(false);

  if (!isOpen) return null;

  const currentCategories = type === 'out' ? EXPENSE_CATEGORIES : INCOME_CATEGORIES;
  const currentAmountNum = parseVietnameseMoneyText(amountStr);

  const handleQuickParse = async () => {
    if (!quickInput.trim()) return;
    setIsParsingQuick(true);

    try {
      // First try calling our smart server Gemini endpoint
      const res = await fetch('/api/gemini/quick-text', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: quickInput, currentDate: date }),
      });

      if (res.ok) {
        const json = await res.json();
        if (json.success && json.data) {
          const parsed = json.data;
          if (parsed.type === 'in' || parsed.type === 'out') {
            setType(parsed.type);
          }
          if (parsed.amount) {
            setAmountStr(String(parsed.amount));
          }
          if (parsed.category) {
            setSelectedCat(parsed.category);
          }
          if (parsed.note) {
            setNote(parsed.note);
          }
          if (parsed.date) {
            setDate(parsed.date);
          }
          if (parsed.account) {
            const accMatch = data.accts.find(a =>
              a.name.toLowerCase().includes(parsed.account.toLowerCase())
            );
            if (accMatch) setSelectedAccount(accMatch.id);
          }
          setIsParsingQuick(false);
          return;
        }
      }
    } catch (e) {
      console.warn('AI Quick parse error, falling back to local rule engine:', e);
    }

    // Local heuristic fallback parser
    const guessedAmount = parseVietnameseMoneyText(quickInput);
    if (guessedAmount > 0) {
      setAmountStr(String(guessedAmount));
    }
    const guessedCat = guessCategoryByText(quickInput);
    if (guessedCat) {
      const isInc = INCOME_CATEGORIES.some(c => c.key === guessedCat);
      setType(isInc ? 'in' : 'out');
      setSelectedCat(guessedCat);
    }
    // Clean note from quick input
    const cleanedNote = quickInput
      .replace(/\d+\s*(k|tr|trieu|tỷ|d|đ|vnd|nghin)?/gi, '')
      .replace(/\s+/g, ' ')
      .trim();
    if (cleanedNote) {
      setNote(cleanedNote.charAt(0).toUpperCase() + cleanedNote.slice(1));
    }

    setIsParsingQuick(false);
  };

  const handleAddAmount = (addValue: number) => {
    const cur = currentAmountNum;
    setAmountStr(String(cur + addValue));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (currentAmountNum <= 0) return;

    addTransaction({
      type,
      cat: selectedCat,
      amount: currentAmountNum,
      date,
      note: note.trim() || undefined,
      accountId: selectedAccount || undefined,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-sm transition-opacity">
      <div className="bg-white dark:bg-slate-900 w-full sm:max-w-lg rounded-t-3xl sm:rounded-3xl max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 dark:border-slate-800 animate-in fade-in slide-in-from-bottom duration-200">
        {/* Header */}
        <div className="px-5 pt-4 pb-3 flex items-center justify-between border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">Ghi Sổ Giao Dịch</h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="overflow-y-auto px-5 py-4 space-y-4">
          {/* Quick Natural Text Input */}
          <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-2xl border border-slate-200/70 dark:border-slate-700/60">
            <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-1.5 font-medium">
              <span className="flex items-center gap-1">
                <Sparkles size={13} className="text-violet-500" />
                <span>Gõ nhanh tự động điền</span>
              </span>
              <span className="text-[11px] text-slate-400">VD: cơm trưa 45k momo</span>
            </div>
            <div className="flex gap-1.5">
              <input
                type="text"
                value={quickInput}
                onChange={e => setQuickInput(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleQuickParse();
                  }
                }}
                placeholder="Nhập: ăn sáng 35k, xăng 60k..."
                className="flex-1 text-xs sm:text-sm bg-white dark:bg-slate-900 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
              />
              <button
                type="button"
                onClick={handleQuickParse}
                disabled={isParsingQuick || !quickInput.trim()}
                className="px-3 py-2 bg-gradient-to-r from-violet-600 to-indigo-600 text-white rounded-xl text-xs font-semibold hover:from-violet-700 hover:to-indigo-700 disabled:opacity-50 transition-all flex items-center gap-1 shrink-0"
              >
                {isParsingQuick ? 'Đang đọc...' : 'Điền'}
              </button>
            </div>
          </div>

          {/* Type Segmented Buttons */}
          <div className="grid grid-cols-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl gap-1">
            <button
              type="button"
              onClick={() => {
                setType('out');
                setSelectedCat('an_uong');
              }}
              className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl font-bold text-sm transition-all ${
                type === 'out'
                  ? 'bg-rose-500 text-white shadow-md shadow-rose-500/20'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <ArrowDownLeft size={18} />
              <span>Tiền Ra (Chi tiêu)</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setType('in');
                setSelectedCat('luong');
              }}
              className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl font-bold text-sm transition-all ${
                type === 'in'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-500/20'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <ArrowUpRight size={18} />
              <span>Tiền Vào (Thu nhập)</span>
            </button>
          </div>

          {/* Big Amount Input */}
          <div className="text-center py-2">
            <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider block mb-1">
              Số tiền giao dịch
            </label>
            <div className="flex items-center justify-center gap-1.5">
              <input
                type="text"
                inputMode="numeric"
                autoFocus
                value={amountStr}
                onChange={e => setAmountStr(e.target.value.replace(/\D/g, ''))}
                placeholder="0"
                className="w-full text-center text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white bg-transparent border-0 border-b-2 border-slate-200 dark:border-slate-700 focus:border-emerald-500 dark:focus:border-emerald-400 focus:outline-none pb-1"
              />
              <span className="text-2xl font-bold text-slate-400">₫</span>
            </div>
            {currentAmountNum > 0 && (
              <p className="text-xs font-medium text-emerald-600 dark:text-emerald-400 mt-1">
                = {formatVND(currentAmountNum)}
              </p>
            )}
          </div>

          {/* Quick Amount Adder Chips */}
          <div className="flex flex-wrap gap-1.5 justify-center">
            {[10000, 20000, 50000, 100000, 200000, 500000, 1000000].map(val => (
              <button
                key={val}
                type="button"
                onClick={() => handleAddAmount(val)}
                className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 active:scale-95 transition-all"
              >
                +{val >= 1000000 ? `${val / 1000000}tr` : `${val / 1000}k`}
              </button>
            ))}
            <button
              type="button"
              onClick={() => setAmountStr(prev => (prev ? prev + '000' : ''))}
              className="px-2.5 py-1 text-xs font-bold rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 active:scale-95 transition-all"
            >
              +000
            </button>
            <button
              type="button"
              onClick={() => setAmountStr('')}
              className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 hover:bg-rose-100 active:scale-95 transition-all"
            >
              Xóa
            </button>
          </div>

          {/* Category Selector Grid */}
          <div>
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-2">
              Chọn danh mục
            </label>
            <div className="grid grid-cols-4 sm:grid-cols-4 gap-2 max-h-48 overflow-y-auto p-1 rounded-2xl border border-slate-100 dark:border-slate-800">
              {currentCategories.map(cat => {
                const isSelected = selectedCat === cat.key;
                return (
                  <button
                    key={cat.key}
                    type="button"
                    onClick={() => setSelectedCat(cat.key)}
                    className={`flex flex-col items-center justify-center p-2 rounded-2xl transition-all ${
                      isSelected
                        ? 'ring-2 ring-emerald-500 bg-emerald-50/80 dark:bg-emerald-950/40 font-bold scale-[1.02]'
                        : 'hover:bg-slate-50 dark:hover:bg-slate-800/60 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    <CategoryIcon catKey={cat.key} size="md" />
                    <span className="text-[11px] mt-1 text-center truncate max-w-full leading-tight font-medium">
                      {cat.shortName}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Account / Wallet Selector */}
          <div>
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 flex items-center gap-1.5 mb-1.5">
              <CreditCard size={14} className="text-slate-400" />
              <span>Tài khoản / Ví thanh toán</span>
            </label>
            <select
              value={selectedAccount}
              onChange={e => setSelectedAccount(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
            >
              <option value="">-- Không liên kết ví cụ thể --</option>
              {data.accts.map(acc => (
                <option key={acc.id} value={acc.id}>
                  {acc.name} (Số dư: {formatVND(acc.balance)})
                </option>
              ))}
            </select>
          </div>

          {/* Date & Note Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 flex items-center gap-1.5 mb-1.5">
                <Calendar size={14} className="text-slate-400" />
                <span>Ngày ghi sổ</span>
              </label>
              <input
                type="date"
                value={date}
                onChange={e => setDate(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 flex items-center gap-1.5 mb-1.5">
                <FileText size={14} className="text-slate-400" />
                <span>Ghi chú</span>
              </label>
              <input
                type="text"
                value={note}
                onChange={e => setNote(e.target.value)}
                placeholder="VD: Cơm tấm sườn bì chả..."
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 pb-1 flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 rounded-2xl border border-slate-200 dark:border-slate-700 font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 text-sm transition-colors"
            >
              Hủy
            </button>
            <button
              type="submit"
              disabled={currentAmountNum <= 0}
              className="flex-[2] py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-bold text-sm shadow-md shadow-emerald-500/25 hover:from-emerald-700 hover:to-teal-700 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
            >
              <Check size={18} />
              <span>Lưu Giao Dịch</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
