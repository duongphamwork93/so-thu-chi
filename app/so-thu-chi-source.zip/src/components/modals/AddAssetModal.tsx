import React, { useState } from 'react';
import { X, Check, Building2, PiggyBank, TrendingUp, CreditCard as CardIcon, HandCoins, Target } from 'lucide-react';
import { useFinance } from '../../context/FinanceContext';
import { getTodayDateString, parseVietnameseMoneyText, shiftMonthString } from '../../utils/formatters';
import { AccountType, DebtDirection, InvestmentType } from '../../types/finance';

export type AssetCategoryType = 'account' | 'deposit' | 'holding' | 'card' | 'debt' | 'goal';

interface AddAssetModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialCategory?: AssetCategoryType;
}

export const AddAssetModal: React.FC<AddAssetModalProps> = ({
  isOpen,
  onClose,
  initialCategory = 'account',
}) => {
  const { addAccount, addDeposit, addHolding, addCreditCard, addDebt, addGoal } = useFinance();
  const [assetType, setAssetType] = useState<AssetCategoryType>(initialCategory);

  // Form states for Account
  const [accName, setAccName] = useState('');
  const [accType, setAccType] = useState<AccountType>('bank');
  const [accBalanceStr, setAccBalanceStr] = useState('');

  // Form states for Deposit
  const [depBank, setDepBank] = useState('Vietcombank');
  const [depAmountStr, setDepAmountStr] = useState('');
  const [depTerm, setDepTerm] = useState('6');
  const [depRate, setDepRate] = useState('5.2');
  const [depStart, setDepStart] = useState(getTodayDateString());

  // Form states for Holding
  const [invCode, setInvCode] = useState('');
  const [invName, setInvName] = useState('');
  const [invType, setInvType] = useState<InvestmentType>('stock');
  const [invQtyStr, setInvQtyStr] = useState('100');
  const [invBuyPriceStr, setInvBuyPriceStr] = useState('');
  const [invCurPriceStr, setInvCurPriceStr] = useState('');

  // Form states for Card
  const [cardName, setCardName] = useState('');
  const [cardLimitStr, setCardLimitStr] = useState('50000000');
  const [cardBalStr, setCardBalStr] = useState('0');
  const [cardStmtDay, setCardStmtDay] = useState('15');
  const [cardDueDay, setCardDueDay] = useState('5');

  // Form states for Debt
  const [debtDir, setDebtDir] = useState<DebtDirection>('lend');
  const [debtName, setDebtName] = useState('');
  const [debtTarget, setDebtTarget] = useState('');
  const [debtAmountStr, setDebtAmountStr] = useState('');
  const [debtDue, setDebtDue] = useState('');

  // Form states for Goal
  const [goalTitle, setGoalTitle] = useState('');
  const [goalTargetStr, setGoalTargetStr] = useState('');
  const [goalCurrentStr, setGoalCurrentStr] = useState('0');
  const [goalDate, setGoalDate] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (assetType === 'account') {
      const bal = parseVietnameseMoneyText(accBalanceStr);
      if (!accName.trim()) return;
      addAccount({
        name: accName.trim(),
        type: accType,
        balance: bal,
      });
    } else if (assetType === 'deposit') {
      const amt = parseVietnameseMoneyText(depAmountStr);
      const term = Number(depTerm) || 6;
      const rate = Number(depRate) || 5;
      if (amt <= 0) return;

      const maturityDate = shiftMonthString(depStart.slice(0, 7), term) + depStart.slice(7);
      addDeposit({
        bank: depBank.trim(),
        amount: amt,
        termMonths: term,
        interestRate: rate,
        startDate: depStart,
        maturityDate,
        rollover: 'all',
      });
    } else if (assetType === 'holding') {
      const qty = parseFloat(invQtyStr) || 0;
      const buyP = parseVietnameseMoneyText(invBuyPriceStr);
      const curP = parseVietnameseMoneyText(invCurPriceStr) || buyP;
      if (!invCode.trim() || qty <= 0 || buyP <= 0) return;

      addHolding({
        code: invCode.trim().toUpperCase(),
        name: invName.trim() || invCode.trim().toUpperCase(),
        type: invType,
        quantity: qty,
        buyPrice: buyP,
        currentPrice: curP,
      });
    } else if (assetType === 'card') {
      const limit = parseVietnameseMoneyText(cardLimitStr);
      const bal = parseVietnameseMoneyText(cardBalStr);
      if (!cardName.trim() || limit <= 0) return;

      addCreditCard({
        name: cardName.trim(),
        bank: cardName.trim().split(' ')[0] || 'Ngân hàng',
        limit,
        currentBalance: bal,
        statementDay: Number(cardStmtDay) || 15,
        dueDay: Number(cardDueDay) || 5,
      });
    } else if (assetType === 'debt') {
      const amt = parseVietnameseMoneyText(debtAmountStr);
      if (!debtName.trim() || !debtTarget.trim() || amt <= 0) return;

      addDebt({
        dir: debtDir,
        name: debtName.trim(),
        targetName: debtTarget.trim(),
        amount: amt,
        paidAmount: 0,
        dueDate: debtDue || undefined,
      });
    } else if (assetType === 'goal') {
      const targetAmt = parseVietnameseMoneyText(goalTargetStr);
      const curAmt = parseVietnameseMoneyText(goalCurrentStr);
      if (!goalTitle.trim() || targetAmt <= 0) return;

      addGoal({
        title: goalTitle.trim(),
        targetAmount: targetAmt,
        currentAmount: curAmt,
        targetDate: goalDate || undefined,
      });
    }

    onClose();
  };

  const navCategories = [
    { key: 'account' as AssetCategoryType, label: 'Ví / Ngân hàng', icon: Building2 },
    { key: 'deposit' as AssetCategoryType, label: 'Sổ tiết kiệm', icon: PiggyBank },
    { key: 'holding' as AssetCategoryType, label: 'Đầu tư', icon: TrendingUp },
    { key: 'card' as AssetCategoryType, label: 'Thẻ tín dụng', icon: CardIcon },
    { key: 'debt' as AssetCategoryType, label: 'Sổ nợ / Vay', icon: HandCoins },
    { key: 'goal' as AssetCategoryType, label: 'Mục tiêu', icon: Target },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-sm transition-opacity">
      <div className="bg-white dark:bg-slate-900 w-full sm:max-w-lg rounded-t-3xl sm:rounded-3xl max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 dark:border-slate-800 animate-in fade-in slide-in-from-bottom duration-200">
        {/* Header */}
        <div className="px-5 pt-4 pb-3 flex items-center justify-between border-b border-slate-100 dark:border-slate-800">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">Thêm Mục Tài Sản & Nợ</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X size={20} />
          </button>
        </div>

        {/* Tab pills */}
        <div className="flex gap-1 overflow-x-auto p-3 bg-slate-50 dark:bg-slate-850 border-b border-slate-100 dark:border-slate-800 no-scrollbar">
          {navCategories.map(cat => {
            const Icon = cat.icon;
            const isSelected = assetType === cat.key;
            return (
              <button
                key={cat.key}
                type="button"
                onClick={() => setAssetType(cat.key)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-500/20'
                    : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                }`}
              >
                <Icon size={14} />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4">
          {/* 1. Account / Wallet Form */}
          {assetType === 'account' && (
            <>
              <div>
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                  Tên tài khoản / ví
                </label>
                <input
                  type="text"
                  required
                  value={accName}
                  onChange={e => setAccName(e.target.value)}
                  placeholder="VD: Vietcombank Lương, Ví MoMo..."
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                    Loại tài khoản
                  </label>
                  <select
                    value={accType}
                    onChange={e => setAccType(e.target.value as AccountType)}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                  >
                    <option value="bank">Ngân hàng</option>
                    <option value="wallet">Ví điện tử (MoMo, ZaloPay)</option>
                    <option value="cash">Tiền mặt</option>
                    <option value="invest">Tài khoản chứng khoán</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                    Số dư hiện tại (₫)
                  </label>
                  <input
                    type="text"
                    inputMode="numeric"
                    required
                    value={accBalanceStr}
                    onChange={e => setAccBalanceStr(e.target.value)}
                    placeholder="VD: 15tr, 15000000"
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>
              </div>
            </>
          )}

          {/* 2. Deposit Form */}
          {assetType === 'deposit' && (
            <>
              <div>
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                  Ngân hàng gửi tiết kiệm
                </label>
                <input
                  type="text"
                  required
                  value={depBank}
                  onChange={e => setDepBank(e.target.value)}
                  placeholder="VD: Vietcombank, MB Bank, Techcombank..."
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                    Số tiền gửi (₫)
                  </label>
                  <input
                    type="text"
                    required
                    value={depAmountStr}
                    onChange={e => setDepAmountStr(e.target.value)}
                    placeholder="VD: 50tr, 100000000"
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                    Lãi suất (% / năm)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={depRate}
                    onChange={e => setDepRate(e.target.value)}
                    placeholder="5.2"
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                    Kỳ hạn (tháng)
                  </label>
                  <select
                    value={depTerm}
                    onChange={e => setDepTerm(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                  >
                    <option value="1">1 tháng</option>
                    <option value="3">3 tháng</option>
                    <option value="6">6 tháng</option>
                    <option value="9">9 tháng</option>
                    <option value="12">12 tháng (1 năm)</option>
                    <option value="18">18 tháng</option>
                    <option value="24">24 tháng (2 năm)</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                    Ngày bắt đầu gửi
                  </label>
                  <input
                    type="date"
                    required
                    value={depStart}
                    onChange={e => setDepStart(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>
              </div>
            </>
          )}

          {/* 3. Holding Form */}
          {assetType === 'holding' && (
            <>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                    Mã / Ký hiệu
                  </label>
                  <input
                    type="text"
                    required
                    value={invCode}
                    onChange={e => setInvCode(e.target.value)}
                    placeholder="VD: FPT, DCDS, SJC..."
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none uppercase"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                    Loại đầu tư
                  </label>
                  <select
                    value={invType}
                    onChange={e => setInvType(e.target.value as InvestmentType)}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                  >
                    <option value="stock">Cổ phiếu</option>
                    <option value="fund">Chứng chỉ quỹ (ETF/Mở)</option>
                    <option value="gold">Vàng (SJC/Nhẫn 9999)</option>
                    <option value="real_estate">Bất động sản</option>
                    <option value="crypto">Tài sản số (Crypto)</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                  Tên đầy đủ tài sản
                </label>
                <input
                  type="text"
                  value={invName}
                  onChange={e => setInvName(e.target.value)}
                  placeholder="VD: Cổ phiếu FPT, Vàng nhẫn 9999 PNJ..."
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                />
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                    Số lượng
                  </label>
                  <input
                    type="number"
                    step="any"
                    required
                    value={invQtyStr}
                    onChange={e => setInvQtyStr(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                    Giá mua (₫)
                  </label>
                  <input
                    type="text"
                    required
                    value={invBuyPriceStr}
                    onChange={e => setInvBuyPriceStr(e.target.value)}
                    placeholder="120k"
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                    Giá hiện tại (₫)
                  </label>
                  <input
                    type="text"
                    value={invCurPriceStr}
                    onChange={e => setInvCurPriceStr(e.target.value)}
                    placeholder="135k"
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>
              </div>
            </>
          )}

          {/* 4. Credit Card Form */}
          {assetType === 'card' && (
            <>
              <div>
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                  Tên thẻ tín dụng
                </label>
                <input
                  type="text"
                  required
                  value={cardName}
                  onChange={e => setCardName(e.target.value)}
                  placeholder="VD: HSBC Visa Platinum, VCB Cashback..."
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                    Hạn mức tín dụng (₫)
                  </label>
                  <input
                    type="text"
                    required
                    value={cardLimitStr}
                    onChange={e => setCardLimitStr(e.target.value)}
                    placeholder="50tr"
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                    Dư nợ hiện tại (₫)
                  </label>
                  <input
                    type="text"
                    value={cardBalStr}
                    onChange={e => setCardBalStr(e.target.value)}
                    placeholder="0"
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                    Ngày chốt sao kê hàng tháng
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="31"
                    value={cardStmtDay}
                    onChange={e => setCardStmtDay(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                    Ngày hạn thanh toán hàng tháng
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="31"
                    value={cardDueDay}
                    onChange={e => setCardDueDay(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>
              </div>
            </>
          )}

          {/* 5. Debt Form */}
          {assetType === 'debt' && (
            <>
              <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
                <button
                  type="button"
                  onClick={() => setDebtDir('lend')}
                  className={`py-2 rounded-lg text-xs font-bold transition-all ${
                    debtDir === 'lend'
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  Cho người khác vay (+)
                </button>
                <button
                  type="button"
                  onClick={() => setDebtDir('borrow')}
                  className={`py-2 rounded-lg text-xs font-bold transition-all ${
                    debtDir === 'borrow'
                      ? 'bg-rose-500 text-white shadow-sm'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  Mình đi vay / Trả góp (-)
                </button>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                    Mô tả khoản nợ
                  </label>
                  <input
                    type="text"
                    required
                    value={debtName}
                    onChange={e => setDebtName(e.target.value)}
                    placeholder="VD: Trả góp xe, Cho Tuấn mượn"
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                    {debtDir === 'lend' ? 'Người vay tiền' : 'Chủ nợ / Bên cho vay'}
                  </label>
                  <input
                    type="text"
                    required
                    value={debtTarget}
                    onChange={e => setDebtTarget(e.target.value)}
                    placeholder="VD: Nguyễn Văn A, FE Credit..."
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                    Tổng số tiền (₫)
                  </label>
                  <input
                    type="text"
                    required
                    value={debtAmountStr}
                    onChange={e => setDebtAmountStr(e.target.value)}
                    placeholder="VD: 5tr, 10000000"
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                    Hạn hẹn trả
                  </label>
                  <input
                    type="date"
                    value={debtDue}
                    onChange={e => setDebtDue(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>
              </div>
            </>
          )}

          {/* 6. Goal Form */}
          {assetType === 'goal' && (
            <>
              <div>
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                  Tên mục tiêu tiết kiệm
                </label>
                <input
                  type="text"
                  required
                  value={goalTitle}
                  onChange={e => setGoalTitle(e.target.value)}
                  placeholder="VD: Mua xe máy mới, Quỹ dự phòng..."
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                    Mục tiêu cần đạt (₫)
                  </label>
                  <input
                    type="text"
                    required
                    value={goalTargetStr}
                    onChange={e => setGoalTargetStr(e.target.value)}
                    placeholder="VD: 50tr, 100000000"
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                    Số tiền hiện đã có (₫)
                  </label>
                  <input
                    type="text"
                    value={goalCurrentStr}
                    onChange={e => setGoalCurrentStr(e.target.value)}
                    placeholder="VD: 10tr"
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block mb-1">
                  Thời hạn dự kiến hoàn thành
                </label>
                <input
                  type="date"
                  value={goalDate}
                  onChange={e => setGoalDate(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
                />
              </div>
            </>
          )}

          {/* Submit */}
          <div className="pt-3 flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-semibold text-sm"
            >
              Hủy
            </button>
            <button
              type="submit"
              className="flex-[2] py-2.5 rounded-xl bg-emerald-600 text-white font-bold text-sm hover:bg-emerald-700 flex items-center justify-center gap-1.5 shadow-md shadow-emerald-500/20"
            >
              <Check size={18} />
              <span>Thêm Ngay</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
