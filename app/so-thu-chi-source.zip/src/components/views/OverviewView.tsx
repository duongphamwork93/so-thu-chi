import React from 'react';
import {
  ArrowDownLeft,
  ArrowUpRight,
  TrendingUp,
  AlertTriangle,
  Clock,
  Sparkles,
  ChevronRight,
  Target,
  PiggyBank,
  CheckCircle2,
} from 'lucide-react';
import { useFinance } from '../../context/FinanceContext';
import { CATEGORY_MAP } from '../../constants/categories';
import { CategoryIcon } from '../CategoryIcon';
import {
  calculateDepositAccrued,
  formatDateVietnamese,
  formatVND,
  formatVNDShort,
} from '../../utils/formatters';

interface OverviewViewProps {
  onNavigateTab: (tab: any) => void;
  onOpenAddModal: () => void;
}

export const OverviewView: React.FC<OverviewViewProps> = ({ onNavigateTab, onOpenAddModal }) => {
  const { data, currentMonth, recordRecurringNow } = useFinance();

  // Filter transactions for current month
  const monthTransactions = data.records.filter(r => r.date && r.date.startsWith(currentMonth));
  const incomeList = monthTransactions.filter(r => r.type === 'in');
  const expenseList = monthTransactions.filter(r => r.type === 'out');

  const totalIncome = incomeList.reduce((sum, r) => sum + r.amount, 0);
  const totalExpense = expenseList.reduce((sum, r) => sum + r.amount, 0);
  const netSavings = totalIncome - totalExpense;
  const savingsRate = totalIncome > 0 ? Math.round((netSavings / totalIncome) * 100) : 0;

  // 50/30/20 breakdown
  const groupTotals = { need: 0, want: 0, save: 0 };
  const catTotals: Record<string, number> = {};

  expenseList.forEach(r => {
    catTotals[r.cat] = (catTotals[r.cat] || 0) + r.amount;
    const cat = CATEGORY_MAP[r.cat];
    const grp = cat?.group === 'need' ? 'need' : cat?.group === 'save' ? 'save' : 'want';
    groupTotals[grp] += r.amount;
  });

  const needPct = totalExpense > 0 ? Math.round((groupTotals.need / totalExpense) * 100) : 0;
  const wantPct = totalExpense > 0 ? Math.round((groupTotals.want / totalExpense) * 100) : 0;
  const savePct = totalExpense > 0 ? Math.round((groupTotals.save / totalExpense) * 100) : 0;

  // Sorted categories by spending
  const topCategories = Object.entries(catTotals)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5);

  // Budget
  const monthlyBudget = data.settings.budget || 0;
  const budgetPct = monthlyBudget > 0 ? Math.round((totalExpense / monthlyBudget) * 100) : 0;
  const budgetRemaining = monthlyBudget - totalExpense;

  // Smart due reminders
  const dueItems: Array<{
    id: string;
    type: 'card' | 'dep' | 'debt' | 'rec';
    title: string;
    subtitle: string;
    amount?: number;
    badge: string;
    isUrgent?: boolean;
    action?: () => void;
  }> = [];

  // 1. Credit cards due
  const todayDay = new Date().getDate();
  data.cards.forEach(card => {
    if (card.currentBalance > 0) {
      const daysUntilDue = card.dueDay >= todayDay ? card.dueDay - todayDay : 30 - todayDay + card.dueDay;
      if (daysUntilDue <= 7) {
        dueItems.push({
          id: card.id,
          type: 'card',
          title: `Thẻ ${card.name} đến hạn`,
          subtitle: `Hạn thanh toán ngày ${card.dueDay} hàng tháng`,
          amount: card.currentBalance,
          badge: daysUntilDue === 0 ? 'Hạn hôm nay' : `Còn ${daysUntilDue} ngày`,
          isUrgent: daysUntilDue <= 3,
        });
      }
    }
  });

  // 2. Deposits maturing soon
  data.deps
    .filter(d => !d.closed)
    .forEach(dep => {
      const { daysLeft, accrued } = calculateDepositAccrued(dep);
      if (daysLeft <= 14) {
        dueItems.push({
          id: dep.id,
          type: 'dep',
          title: `Sổ tiết kiệm ${dep.bank} sắp đáo hạn`,
          subtitle: `Gốc ${formatVNDShort(dep.amount)} + Lãi dự tính ${formatVNDShort(accrued)}`,
          amount: dep.amount,
          badge: daysLeft === 0 ? 'Đáo hạn hôm nay' : `Còn ${daysLeft} ngày`,
          isUrgent: false,
        });
      }
    });

  // 3. Debts due
  data.debts
    .filter(d => !d.closed && d.dueDate)
    .forEach(debt => {
      const remaining = debt.amount - (debt.paidAmount || 0);
      dueItems.push({
        id: debt.id,
        type: 'debt',
        title: debt.dir === 'lend' ? `Thu hồi nợ từ ${debt.targetName}` : `Trả nợ cho ${debt.targetName}`,
        subtitle: debt.name,
        amount: remaining,
        badge: `Hạn: ${debt.dueDate?.slice(8)}/${debt.dueDate?.slice(5, 7)}`,
        isUrgent: false,
      });
    });

  // 4. Pending recurring
  data.recs.forEach(rec => {
    const isDue = rec.dayOfMonth <= todayDay && rec.lastRecorded !== currentMonth;
    if (isDue) {
      dueItems.push({
        id: rec.id,
        type: 'rec',
        title: `Đến hạn: ${rec.name}`,
        subtitle: `Ngày ${rec.dayOfMonth} hàng tháng`,
        amount: rec.amount,
        badge: 'Ghi ngay',
        isUrgent: true,
        action: () => recordRecurringNow(rec.id),
      });
    }
  });

  return (
    <div className="space-y-5 pb-24">
      {/* 1. Main Hero Financial Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white p-6 shadow-xl border border-indigo-900/40">
        <div className="absolute top-0 right-0 -mr-10 -mt-10 w-44 h-44 rounded-full bg-emerald-500/10 blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-10 -mb-10 w-44 h-44 rounded-full bg-indigo-500/10 blur-2xl pointer-events-none" />

        <div className="relative z-10 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs uppercase tracking-wider font-semibold text-indigo-300/90">
              Thặng Dư / Tiết Kiệm Tháng
            </span>
            <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-white/10 backdrop-blur-md border border-white/10">
              <TrendingUp size={13} className={netSavings >= 0 ? 'text-emerald-400' : 'text-rose-400'} />
              <span>{savingsRate >= 0 ? `+${savingsRate}%` : `${savingsRate}%`} tích lũy</span>
            </div>
          </div>

          <div className="money-mask">
            <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-white flex items-baseline gap-1">
              <span>{formatVND(netSavings)}</span>
            </h2>
          </div>

          {/* Income & Expense sub-cards */}
          <div className="grid grid-cols-2 gap-3 pt-2">
            <div className="bg-white/10 dark:bg-white/5 backdrop-blur-md rounded-2xl p-3 border border-white/10">
              <div className="flex items-center gap-1.5 text-xs text-emerald-300 font-medium mb-1">
                <ArrowUpRight size={15} />
                <span>Tổng Thu</span>
              </div>
              <div className="money-mask font-bold text-base sm:text-lg text-emerald-300">
                {formatVND(totalIncome)}
              </div>
            </div>

            <div className="bg-white/10 dark:bg-white/5 backdrop-blur-md rounded-2xl p-3 border border-white/10">
              <div className="flex items-center gap-1.5 text-xs text-rose-300 font-medium mb-1">
                <ArrowDownLeft size={15} />
                <span>Tổng Chi</span>
              </div>
              <div className="money-mask font-bold text-base sm:text-lg text-rose-300">
                {formatVND(totalExpense)}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Monthly Budget Card */}
      {monthlyBudget > 0 && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
          <div className="flex items-center justify-between text-xs sm:text-sm">
            <div className="flex items-center gap-2">
              <Target size={18} className="text-emerald-600 dark:text-emerald-400" />
              <span className="font-bold text-slate-900 dark:text-white">Ngân Sách Chi Tiêu Tháng</span>
            </div>
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              {formatVNDShort(totalExpense)} / {formatVNDShort(monthlyBudget)} ({budgetPct}%)
            </span>
          </div>

          {/* Progress bar */}
          <div className="h-3 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden p-0.5">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                budgetPct >= 100
                  ? 'bg-rose-500'
                  : budgetPct >= 85
                  ? 'bg-amber-500'
                  : 'bg-emerald-500'
              }`}
              style={{ width: `${Math.min(100, budgetPct)}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-400">
            <span>
              {budgetRemaining >= 0 ? (
                <span className="text-emerald-600 dark:text-emerald-400 font-semibold">
                  Còn lại: {formatVND(budgetRemaining)}
                </span>
              ) : (
                <span className="text-rose-500 font-bold">
                  Vượt mức: {formatVND(Math.abs(budgetRemaining))}
                </span>
              )}
            </span>
            <button
              onClick={() => onNavigateTab('settings')}
              className="text-indigo-600 dark:text-indigo-400 font-semibold hover:underline"
            >
              Điều chỉnh
            </button>
          </div>
        </div>
      )}

      {/* 3. 50/30/20 Rule Analysis */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <PiggyBank size={18} className="text-indigo-600 dark:text-indigo-400" />
            <h3 className="font-bold text-slate-900 dark:text-white text-sm sm:text-base">
              Phân Bổ Chi Tiêu (Quy Tắc 50/30/20)
            </h3>
          </div>
          <span className="text-xs text-slate-400 font-medium">Chuẩn tài chính</span>
        </div>

        {/* Stacked bar */}
        <div className="h-3.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden flex">
          <div
            className="bg-blue-600 h-full transition-all"
            style={{ width: `${needPct}%` }}
            title={`Thiết yếu: ${needPct}%`}
          />
          <div
            className="bg-amber-500 h-full transition-all"
            style={{ width: `${wantPct}%` }}
            title={`Mong muốn: ${wantPct}%`}
          />
          <div
            className="bg-emerald-500 h-full transition-all"
            style={{ width: `${savePct}%` }}
            title={`Tích luỹ: ${savePct}%`}
          />
        </div>

        {/* 3 Pills */}
        <div className="grid grid-cols-3 gap-2 text-center text-xs">
          <div className="p-2.5 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200/60 dark:border-blue-900/40">
            <div className="text-[10px] uppercase font-bold text-blue-700 dark:text-blue-400">
              Thiết yếu (50%)
            </div>
            <div className="font-bold text-blue-900 dark:text-blue-200 text-sm mt-0.5">
              {needPct}%
            </div>
            <div className="text-[10px] text-blue-600/80 dark:text-blue-400/80 truncate money-mask">
              {formatVNDShort(groupTotals.need)}
            </div>
          </div>

          <div className="p-2.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200/60 dark:border-amber-900/40">
            <div className="text-[10px] uppercase font-bold text-amber-700 dark:text-amber-400">
              Sở thích (30%)
            </div>
            <div className="font-bold text-amber-900 dark:text-amber-200 text-sm mt-0.5">
              {wantPct}%
            </div>
            <div className="text-[10px] text-amber-600/80 dark:text-amber-400/80 truncate money-mask">
              {formatVNDShort(groupTotals.want)}
            </div>
          </div>

          <div className="p-2.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200/60 dark:border-emerald-900/40">
            <div className="text-[10px] uppercase font-bold text-emerald-700 dark:text-emerald-400">
              Tích lũy (20%)
            </div>
            <div className="font-bold text-emerald-900 dark:text-emerald-200 text-sm mt-0.5">
              {savePct}%
            </div>
            <div className="text-[10px] text-emerald-600/80 dark:text-emerald-400/80 truncate money-mask">
              {formatVNDShort(groupTotals.save)}
            </div>
          </div>
        </div>
      </div>

      {/* 4. Smart Reminders & Due Dates (If any) */}
      {dueItems.length > 0 && (
        <div className="space-y-2.5">
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
              <Clock size={14} className="text-amber-500" />
              <span>Việc Cần Lưu Ý & Đến Hạn ({dueItems.length})</span>
            </div>
          </div>

          <div className="space-y-2">
            {dueItems.slice(0, 4).map(item => (
              <div
                key={item.id}
                className="bg-white dark:bg-slate-900 p-3.5 rounded-2xl border border-slate-200/80 dark:border-slate-800 flex items-center justify-between gap-3 shadow-xs hover:border-slate-300 dark:hover:border-slate-700 transition-colors"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white truncate">
                      {item.title}
                    </span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        item.isUrgent
                          ? 'bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-400'
                          : 'bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400'
                      }`}
                    >
                      {item.badge}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5">
                    {item.subtitle}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {item.amount !== undefined && (
                    <span className="money-mask text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-200">
                      {formatVND(item.amount)}
                    </span>
                  )}
                  {item.action && (
                    <button
                      onClick={item.action}
                      className="px-2.5 py-1 text-xs font-bold rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 active:scale-95 transition-all"
                    >
                      Ghi ngay
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. Top Spending Categories */}
      {topCategories.length > 0 && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3.5">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-900 dark:text-white text-sm sm:text-base">
              Chi Tiêu Nhiều Nhất Tháng Này
            </h3>
            <button
              onClick={() => onNavigateTab('ledger')}
              className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-0.5"
            >
              <span>Xem tất cả</span>
              <ChevronRight size={14} />
            </button>
          </div>

          <div className="space-y-3">
            {topCategories.map(([catKey, amount]) => {
              const cat = CATEGORY_MAP[catKey] || { name: 'Khác', color: '#64748B' };
              const percent = totalExpense > 0 ? Math.round((amount / totalExpense) * 100) : 0;
              return (
                <div key={catKey} className="space-y-1">
                  <div className="flex items-center justify-between text-xs sm:text-sm">
                    <div className="flex items-center gap-2 min-w-0">
                      <CategoryIcon catKey={catKey} size="sm" />
                      <span className="font-medium text-slate-800 dark:text-slate-200 truncate">
                        {cat.name}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 font-semibold">
                      <span className="text-slate-400 text-xs">{percent}%</span>
                      <span className="money-mask text-slate-900 dark:text-white">
                        {formatVND(amount)}
                      </span>
                    </div>
                  </div>
                  <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{ width: `${percent}%`, backgroundColor: cat.color }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 6. Recent Transactions */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <span className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
            Giao Dịch Gần Đây
          </span>
          <button
            onClick={() => onNavigateTab('ledger')}
            className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline"
          >
            Mở sổ thu chi ({data.records.length})
          </button>
        </div>

        {monthTransactions.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-8 border border-dashed border-slate-300 dark:border-slate-800 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 flex items-center justify-center mx-auto">
              <CheckCircle2 size={24} />
            </div>
            <div>
              <p className="text-sm font-bold text-slate-800 dark:text-slate-200">
                Chưa có giao dịch nào trong tháng này
              </p>
              <p className="text-xs text-slate-400 mt-0.5">
                Hãy bắt đầu ghi lại các khoản chi tiêu hàng ngày hoặc tải dữ liệu mẫu
              </p>
            </div>
            <button
              onClick={onOpenAddModal}
              className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold shadow-sm shadow-emerald-500/20 hover:bg-emerald-700 transition-colors"
            >
              + Ghi giao dịch đầu tiên
            </button>
          </div>
        ) : (
          <div className="bg-white dark:bg-slate-900 rounded-3xl divide-y divide-slate-100 dark:divide-slate-800/80 border border-slate-200/80 dark:border-slate-800 shadow-sm overflow-hidden">
            {monthTransactions.slice(0, 6).map(tx => {
              const cat = CATEGORY_MAP[tx.cat] || { name: 'Khác' };
              const isExpense = tx.type === 'out';
              return (
                <div
                  key={tx.id}
                  className="p-3.5 flex items-center justify-between gap-3 hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <CategoryIcon catKey={tx.cat} size="md" />
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                        {tx.note || cat.name}
                      </p>
                      <div className="flex items-center gap-1.5 text-xs text-slate-400">
                        <span>{formatDateVietnamese(tx.date)}</span>
                        {tx.accountId && (
                          <>
                            <span>•</span>
                            <span className="truncate max-w-[120px]">
                              {data.accts.find(a => a.id === tx.accountId)?.name}
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span
                      className={`money-mask font-bold text-sm sm:text-base ${
                        isExpense ? 'text-slate-900 dark:text-white' : 'text-emerald-600 dark:text-emerald-400'
                      }`}
                    >
                      {isExpense ? '-' : '+'}
                      {formatVND(tx.amount)}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
