import React, { useState } from 'react';
import {
  Wallet,
  PiggyBank,
  TrendingUp,
  CreditCard as CardIcon,
  HandCoins,
  Target,
  Plus,
  ArrowRightLeft,
  Calendar,
  AlertCircle,
  CheckCircle,
  Coins,
  ShieldCheck,
  ChevronRight,
  Percent,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useFinance } from '../../context/FinanceContext';
import {
  calculateDepositAccrued,
  calculateHoldingValue,
  calculateNetWorthBreakdown,
  formatVND,
  formatVNDShort,
} from '../../utils/formatters';
import { AssetCategoryType } from '../modals/AddAssetModal';

interface AssetsViewProps {
  onOpenAddAsset: (type: AssetCategoryType) => void;
  onOpenTransfer: () => void;
}

export const AssetsView: React.FC<AssetsViewProps> = ({ onOpenAddAsset, onOpenTransfer }) => {
  const {
    data,
    deleteAccount,
    closeDeposit,
    deleteDeposit,
    deleteHolding,
    payCreditCard,
    recordDebtPayment,
    deleteDebt,
    contributeGoal,
    deleteGoal,
  } = useFinance();

  const [activeSubTab, setActiveSubTab] = useState<AssetCategoryType>('account');

  // Breakdown calculations
  const breakdown = calculateNetWorthBreakdown(data);

  // Helper trigger celebration
  const triggerCelebration = () => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
    });
  };

  return (
    <div className="space-y-4 pb-24">
      {/* 1. Net Worth Hero Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-800 via-teal-900 to-slate-900 text-white p-6 shadow-xl border border-emerald-700/40">
        <div className="relative z-10 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs uppercase tracking-wider font-semibold text-emerald-200">
              Tổng Tài Sản Ròng (Net Worth)
            </span>
            <div className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-white/10 backdrop-blur-md border border-white/10 text-emerald-300">
              Cập nhật trực tiếp
            </div>
          </div>

          <div className="money-mask">
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
              {formatVND(breakdown.netWorth)}
            </h2>
          </div>

          {/* Sub summary: Assets vs Liabilities */}
          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-white/10 text-xs">
            <div>
              <span className="text-emerald-200/80 block">Tổng tài sản (+):</span>
              <span className="money-mask font-bold text-sm text-emerald-300">
                {formatVND(breakdown.totalGrossAssets + breakdown.receivables)}
              </span>
            </div>
            <div>
              <span className="text-rose-200/80 block">Tổng nợ & Thẻ (-):</span>
              <span className="money-mask font-bold text-sm text-rose-300">
                {formatVND(breakdown.totalLiabilities)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Sub Category Navigation Tabs */}
      <div className="flex gap-1.5 overflow-x-auto p-1.5 bg-slate-100 dark:bg-slate-800 rounded-2xl no-scrollbar">
        {[
          { key: 'account' as AssetCategoryType, label: 'Ví & Ngân hàng', count: data.accts.length, icon: Wallet },
          { key: 'deposit' as AssetCategoryType, label: 'Sổ tiết kiệm', count: data.deps.filter(d => !d.closed).length, icon: PiggyBank },
          { key: 'holding' as AssetCategoryType, label: 'Đầu tư & Vàng', count: data.holds.length, icon: TrendingUp },
          { key: 'card' as AssetCategoryType, label: 'Thẻ tín dụng', count: data.cards.length, icon: CardIcon },
          { key: 'debt' as AssetCategoryType, label: 'Vay & Nợ', count: data.debts.filter(d => !d.closed).length, icon: HandCoins },
          { key: 'goal' as AssetCategoryType, label: 'Mục tiêu', count: data.goals.length, icon: Target },
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.key;
          return (
            <button
              key={tab.key}
              onClick={() => setActiveSubTab(tab.key)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <Icon size={14} className={isActive ? 'text-emerald-600 dark:text-emerald-400' : ''} />
              <span>{tab.label}</span>
              {tab.count > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-slate-200 dark:bg-slate-600 text-slate-700 dark:text-slate-200">
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* 3. Sub Tab Content */}

      {/* A. ACCOUNTS & WALLETS */}
      {activeSubTab === 'account' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Tài khoản thanh toán ({formatVND(breakdown.accountsTotal)})
            </span>
            <div className="flex gap-2">
              <button
                onClick={onOpenTransfer}
                className="px-2.5 py-1 text-xs font-semibold rounded-xl bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-900 flex items-center gap-1 hover:bg-blue-100"
              >
                <ArrowRightLeft size={13} />
                <span>Chuyển tiền</span>
              </button>
              <button
                onClick={() => onOpenAddAsset('account')}
                className="px-2.5 py-1 text-xs font-semibold rounded-xl bg-emerald-600 text-white flex items-center gap-1 hover:bg-emerald-700 shadow-xs"
              >
                <Plus size={13} />
                <span>Thêm ví</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {data.accts.map(acc => (
              <div
                key={acc.id}
                className="bg-white dark:bg-slate-900 p-4 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className="w-11 h-11 rounded-2xl flex items-center justify-center font-bold text-white shrink-0 shadow-sm"
                    style={{ backgroundColor: acc.color || '#10B981' }}
                  >
                    <Wallet size={20} />
                  </div>
                  <div className="min-w-0">
                    <p className="font-bold text-slate-900 dark:text-white text-sm truncate">
                      {acc.name}
                    </p>
                    <p className="text-xs text-slate-400 capitalize">
                      {acc.type === 'bank' ? 'Tài khoản ngân hàng' : acc.type === 'wallet' ? 'Ví điện tử' : 'Tiền mặt'}
                    </p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <p className="money-mask font-bold text-base text-slate-900 dark:text-white">
                    {formatVND(acc.balance)}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* B. SAVINGS DEPOSITS */}
      {activeSubTab === 'deposit' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Sổ tiết kiệm ({formatVND(breakdown.depositsTotal)})
            </span>
            <button
              onClick={() => onOpenAddAsset('deposit')}
              className="px-2.5 py-1 text-xs font-semibold rounded-xl bg-emerald-600 text-white flex items-center gap-1 hover:bg-emerald-700 shadow-xs"
            >
              <Plus size={13} />
              <span>Gửi sổ mới</span>
            </button>
          </div>

          {data.deps.length === 0 ? (
            <div className="p-8 bg-white dark:bg-slate-900 rounded-3xl border border-dashed border-slate-200 dark:border-slate-800 text-center">
              <p className="text-xs text-slate-400">Chưa có sổ tiết kiệm nào được tạo.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {data.deps.map(dep => {
                const { accrued, maturityInterest, daysLeft } = calculateDepositAccrued(dep);
                return (
                  <div
                    key={dep.id}
                    className={`bg-white dark:bg-slate-900 p-4 rounded-3xl border shadow-sm space-y-3 ${
                      dep.closed
                        ? 'opacity-60 border-slate-200 dark:border-slate-800'
                        : 'border-slate-200/80 dark:border-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-9 h-9 rounded-xl bg-amber-50 dark:bg-amber-950/50 text-amber-600 flex items-center justify-center font-bold">
                          <PiggyBank size={18} />
                        </div>
                        <div>
                          <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                            {dep.bank} ({dep.termMonths} tháng)
                          </h4>
                          <span className="text-[11px] text-slate-400">
                            Lãi suất: <strong className="text-emerald-600">{dep.interestRate}%/năm</strong>
                          </span>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="money-mask font-bold text-base text-slate-900 dark:text-white">
                          {formatVND(dep.amount)}
                        </span>
                        <div className="text-[11px] text-emerald-600 font-medium">
                          + Lãi: {formatVND(accrued)}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-100 dark:border-slate-800 text-slate-500">
                      <div className="flex items-center gap-1.5">
                        <Calendar size={13} className="text-slate-400" />
                        <span>Đáo hạn: {dep.maturityDate}</span>
                        {!dep.closed && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400 font-bold ml-1">
                            Còn {daysLeft} ngày
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        {!dep.closed && (
                          <button
                            onClick={() => {
                              if (confirm('Tất toán sổ tiết kiệm này?')) {
                                closeDeposit(dep.id, data.accts[0]?.id);
                              }
                            }}
                            className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800"
                          >
                            Tất toán
                          </button>
                        )}
                        <button
                          onClick={() => {
                            if (confirm('Xóa thông tin sổ tiết kiệm?')) {
                              deleteDeposit(dep.id);
                            }
                          }}
                          className="text-xs text-rose-500 hover:underline"
                        >
                          Xóa
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* C. INVESTMENTS & HOLDINGS */}
      {activeSubTab === 'holding' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Danh mục đầu tư & Vàng ({formatVND(breakdown.investmentsTotal)})
            </span>
            <button
              onClick={() => onOpenAddAsset('holding')}
              className="px-2.5 py-1 text-xs font-semibold rounded-xl bg-emerald-600 text-white flex items-center gap-1 hover:bg-emerald-700 shadow-xs"
            >
              <Plus size={13} />
              <span>Thêm mã</span>
            </button>
          </div>

          {data.holds.length === 0 ? (
            <div className="p-8 bg-white dark:bg-slate-900 rounded-3xl border border-dashed border-slate-200 dark:border-slate-800 text-center">
              <p className="text-xs text-slate-400">Chưa có mã đầu tư nào.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {data.holds.map(h => {
                const { value, pnl, pnlPercent } = calculateHoldingValue(h);
                const isProfitable = pnl >= 0;
                return (
                  <div
                    key={h.id}
                    className="bg-white dark:bg-slate-900 p-4 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-2.5"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-extrabold text-base text-slate-900 dark:text-white uppercase">
                            {h.code}
                          </span>
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                            {h.type === 'stock' ? 'Cổ phiếu' : h.type === 'gold' ? 'Vàng' : 'Chứng chỉ quỹ'}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 truncate max-w-[150px]">{h.name}</p>
                      </div>

                      <div className="text-right">
                        <p className="money-mask font-bold text-base text-slate-900 dark:text-white">
                          {formatVND(value)}
                        </p>
                        <p
                          className={`text-xs font-bold ${
                            isProfitable ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-500'
                          }`}
                        >
                          {isProfitable ? '+' : ''}
                          {formatVND(pnl)} ({pnlPercent.toFixed(1)}%)
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[11px] pt-2 border-t border-slate-100 dark:border-slate-800 text-slate-400">
                      <span>SL: {h.quantity} | Giá mua: {formatVNDShort(h.buyPrice)}</span>
                      <button
                        onClick={() => {
                          if (confirm(`Xóa mã ${h.code}?`)) deleteHolding(h.id);
                        }}
                        className="text-rose-500 hover:underline"
                      >
                        Xóa
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* D. CREDIT CARDS */}
      {activeSubTab === 'card' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Thẻ tín dụng (Tổng dư nợ: {formatVND(breakdown.creditCardsDebt)})
            </span>
            <button
              onClick={() => onOpenAddAsset('card')}
              className="px-2.5 py-1 text-xs font-semibold rounded-xl bg-emerald-600 text-white flex items-center gap-1 hover:bg-emerald-700 shadow-xs"
            >
              <Plus size={13} />
              <span>Thêm thẻ</span>
            </button>
          </div>

          {data.cards.map(card => {
            const usagePct = card.limit > 0 ? Math.round((card.currentBalance / card.limit) * 100) : 0;
            return (
              <div
                key={card.id}
                className="bg-white dark:bg-slate-900 p-5 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-slate-800 to-slate-950 text-white flex items-center justify-center font-bold shadow-sm">
                      <CardIcon size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-slate-900 dark:text-white">{card.name}</h4>
                      <p className="text-xs text-slate-400">
                        Sao kê ngày {card.statementDay} • Hạn trả ngày {card.dueDay}
                      </p>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-xs text-slate-400 block">Dư nợ hiện tại:</span>
                    <span className="money-mask font-bold text-base text-rose-500">
                      {formatVND(card.currentBalance)}
                    </span>
                  </div>
                </div>

                {/* Limit usage */}
                <div>
                  <div className="flex justify-between text-xs text-slate-500 mb-1">
                    <span>Hạn mức: {formatVND(card.limit)}</span>
                    <span className="font-bold">{usagePct}%</span>
                  </div>
                  <div className="h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        usagePct >= 80 ? 'bg-rose-500' : 'bg-indigo-600'
                      }`}
                      style={{ width: `${Math.min(100, usagePct)}%` }}
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                  <button
                    onClick={() => {
                      const amountPrompt = prompt(
                        `Nhập số tiền muốn thanh toán cho thẻ ${card.name}:`,
                        String(card.currentBalance)
                      );
                      if (amountPrompt) {
                        const amt = parseFloat(amountPrompt);
                        if (amt > 0 && data.accts[0]) {
                          payCreditCard(card.id, data.accts[0].id, amt);
                          triggerCelebration();
                        }
                      }
                    }}
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors"
                  >
                    Thanh toán thẻ
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* E. DEBTS (VAY & CHO VAY) */}
      {activeSubTab === 'debt' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Sổ nợ (Phải thu: {formatVNDShort(breakdown.receivables)} • Phải trả: {formatVNDShort(breakdown.payables)})
            </span>
            <button
              onClick={() => onOpenAddAsset('debt')}
              className="px-2.5 py-1 text-xs font-semibold rounded-xl bg-emerald-600 text-white flex items-center gap-1 hover:bg-emerald-700 shadow-xs"
            >
              <Plus size={13} />
              <span>Thêm khoản</span>
            </button>
          </div>

          {data.debts.length === 0 ? (
            <div className="p-8 bg-white dark:bg-slate-900 rounded-3xl border border-dashed border-slate-200 dark:border-slate-800 text-center">
              <p className="text-xs text-slate-400">Không có khoản nợ hay cho vay nào.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {data.debts.map(debt => {
                const remaining = debt.amount - (debt.paidAmount || 0);
                const progressPct = debt.amount > 0 ? Math.round(((debt.paidAmount || 0) / debt.amount) * 100) : 0;
                const isLend = debt.dir === 'lend';
                return (
                  <div
                    key={debt.id}
                    className="bg-white dark:bg-slate-900 p-4 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-2.5"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                              isLend
                                ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400'
                                : 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-400'
                            }`}
                          >
                            {isLend ? 'Cho vay (+)' : 'Đi vay (-)'}
                          </span>
                          <span className="font-bold text-sm text-slate-900 dark:text-white">
                            {debt.targetName}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 mt-0.5">{debt.name}</p>
                      </div>

                      <div className="text-right">
                        <span className="text-xs text-slate-400 block">Còn lại:</span>
                        <span className="money-mask font-bold text-base text-slate-900 dark:text-white">
                          {formatVND(remaining)}
                        </span>
                      </div>
                    </div>

                    {/* Progress */}
                    <div>
                      <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                        <span>Đã trả: {formatVND(debt.paidAmount || 0)} / {formatVND(debt.amount)}</span>
                        <span>{progressPct}%</span>
                      </div>
                      <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all ${
                            isLend ? 'bg-emerald-500' : 'bg-rose-500'
                          }`}
                          style={{ width: `${progressPct}%` }}
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                      <span className="text-slate-400">
                        {debt.dueDate ? `Hạn trả: ${debt.dueDate}` : 'Không có hạn'}
                      </span>
                      <div className="flex items-center gap-2">
                        {remaining > 0 && (
                          <button
                            onClick={() => {
                              const promptVal = prompt(
                                `Nhập số tiền ${isLend ? 'thu hồi' : 'trả bớt'}:`,
                                String(remaining)
                              );
                              if (promptVal) {
                                const val = parseFloat(promptVal);
                                if (val > 0) {
                                  recordDebtPayment(debt.id, val, data.accts[0]?.id);
                                  if (val >= remaining) triggerCelebration();
                                }
                              }
                            }}
                            className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-bold text-xs"
                          >
                            {isLend ? 'Ghi thu hồi' : 'Ghi trả nợ'}
                          </button>
                        )}
                        <button
                          onClick={() => {
                            if (confirm('Xóa khoản này?')) deleteDebt(debt.id);
                          }}
                          className="text-rose-500 hover:underline"
                        >
                          Xóa
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* F. SAVINGS GOALS */}
      {activeSubTab === 'goal' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Mục tiêu tiết kiệm ({data.goals.length})
            </span>
            <button
              onClick={() => onOpenAddAsset('goal')}
              className="px-2.5 py-1 text-xs font-semibold rounded-xl bg-emerald-600 text-white flex items-center gap-1 hover:bg-emerald-700 shadow-xs"
            >
              <Plus size={13} />
              <span>Mục tiêu mới</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {data.goals.map(goal => {
              const pct = goal.targetAmount > 0 ? Math.round((goal.currentAmount / goal.targetAmount) * 100) : 0;
              const isDone = pct >= 100;
              return (
                <div
                  key={goal.id}
                  className="bg-white dark:bg-slate-900 p-4 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-10 h-10 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 flex items-center justify-center font-bold">
                        <Target size={20} />
                      </div>
                      <div>
                        <h4 className="font-bold text-sm text-slate-900 dark:text-white">{goal.title}</h4>
                        <p className="text-xs text-slate-400">
                          {goal.targetDate ? `Dự kiến: ${goal.targetDate}` : 'Không thời hạn'}
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-xs font-extrabold text-emerald-600 dark:text-emerald-400">
                        {pct}%
                      </span>
                    </div>
                  </div>

                  {/* Progress bar */}
                  <div>
                    <div className="flex justify-between text-xs text-slate-500 mb-1">
                      <span className="money-mask font-semibold text-slate-900 dark:text-white">
                        {formatVND(goal.currentAmount)}
                      </span>
                      <span>/ {formatVNDShort(goal.targetAmount)}</span>
                    </div>
                    <div className="h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 transition-all"
                        style={{ width: `${Math.min(100, pct)}%` }}
                      />
                    </div>
                  </div>

                  <div className="flex justify-between items-center pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                    <button
                      onClick={() => {
                        if (confirm(`Xóa mục tiêu ${goal.title}?`)) deleteGoal(goal.id);
                      }}
                      className="text-rose-500 hover:underline"
                    >
                      Xóa
                    </button>
                    <button
                      onClick={() => {
                        const amtStr = prompt(`Góp thêm tiền vào "${goal.title}":`, '500000');
                        if (amtStr) {
                          const val = parseFloat(amtStr);
                          if (val > 0) {
                            contributeGoal(goal.id, val, data.accts[0]?.id);
                            if (goal.currentAmount + val >= goal.targetAmount) {
                              triggerCelebration();
                            }
                          }
                        }
                      }}
                      className="px-3 py-1 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold"
                    >
                      + Góp tiền
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
