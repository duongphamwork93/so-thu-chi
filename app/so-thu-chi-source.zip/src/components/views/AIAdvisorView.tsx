import React, { useState } from 'react';
import {
  Camera,
  Upload,
  Sparkles,
  Bot,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  Lightbulb,
  ArrowRight,
  FileText,
  DollarSign,
  Calendar,
  Store,
  RefreshCw,
  Plus,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useFinance } from '../../context/FinanceContext';
import { CATEGORY_MAP } from '../../constants/categories';
import { CategoryIcon } from '../CategoryIcon';
import { calculateNetWorthBreakdown, formatVND } from '../../utils/formatters';

export const AIAdvisorView: React.FC = () => {
  const { data, currentMonth, addTransaction } = useFinance();

  // Tab mode: 'receipt' | 'advisor' | 'quick'
  const [subTab, setSubTab] = useState<'receipt' | 'advisor' | 'quick'>('receipt');

  // 1. Receipt scanner state
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scanResult, setScanResult] = useState<any | null>(null);
  const [scanError, setScanError] = useState<string | null>(null);
  const [hasSavedReceipt, setHasSavedReceipt] = useState<boolean>(false);

  // 2. Financial Advisor state
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [adviceResult, setAdviceResult] = useState<any | null>(null);
  const [adviceError, setAdviceError] = useState<string | null>(null);

  // 3. Quick text state
  const [quickInput, setQuickInput] = useState<string>('');
  const [quickResult, setQuickResult] = useState<any | null>(null);
  const [isQuickProcessing, setIsQuickProcessing] = useState<boolean>(false);

  // Handle image upload / camera
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setScanError(null);
    setScanResult(null);
    setHasSavedReceipt(false);

    const reader = new FileReader();
    reader.onload = () => {
      setSelectedImage(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Perform AI scan on receipt image
  const handleScanReceipt = async () => {
    if (!selectedImage) return;
    setIsScanning(true);
    setScanError(null);

    try {
      const res = await fetch('/api/gemini/parse-receipt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: selectedImage,
          mimeType: selectedImage.startsWith('data:image/png') ? 'image/png' : 'image/jpeg',
        }),
      });

      const json = await res.json();
      if (!res.ok || !json.success) {
        throw new Error(json.error || 'Không thể bóc tách ảnh');
      }

      setScanResult(json.data);
      confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
    } catch (err: any) {
      setScanError(err.message || 'Lỗi khi kết nối với máy chủ AI');
    } finally {
      setIsScanning(false);
    }
  };

  // Save scanned receipt as transaction
  const handleSaveScannedReceipt = () => {
    if (!scanResult) return;
    addTransaction({
      type: scanResult.type === 'in' ? 'in' : 'out',
      cat: scanResult.category || 'an_uong',
      amount: scanResult.amount || 0,
      date: scanResult.date || new Date().toISOString().slice(0, 10),
      note: `${scanResult.merchant || 'Hóa đơn'}: ${scanResult.note || ''}`.trim(),
      accountId: data.accts[0]?.id,
    });
    setHasSavedReceipt(true);
    confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
  };

  // Run AI Financial Advisor
  const handleGenerateAdvice = async () => {
    setIsAnalyzing(true);
    setAdviceError(null);

    const monthRecords = data.records.filter(r => r.date?.startsWith(currentMonth));
    const income = monthRecords.filter(r => r.type === 'in').reduce((s, r) => s + r.amount, 0);
    const expense = monthRecords.filter(r => r.type === 'out').reduce((s, r) => s + r.amount, 0);
    const byCategory: Record<string, number> = {};
    monthRecords.filter(r => r.type === 'out').forEach(r => {
      byCategory[r.cat] = (byCategory[r.cat] || 0) + r.amount;
    });

    const nw = calculateNetWorthBreakdown(data);

    try {
      const res = await fetch('/api/gemini/advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          month: currentMonth,
          income,
          expense,
          budget: data.settings.budget,
          byCategory,
          netWorth: nw.netWorth,
          debts: nw.totalLiabilities,
          savings: nw.depositsTotal + nw.investmentsTotal,
        }),
      });

      const json = await res.json();
      if (!res.ok || !json.success) {
        throw new Error(json.error || 'Không thể tạo phân tích tài chính');
      }

      setAdviceResult(json.data);
    } catch (err: any) {
      setAdviceError(err.message || 'Lỗi khi tạo lời khuyên tài chính');
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Handle quick text AI parse
  const handleQuickTextParse = async () => {
    if (!quickInput.trim()) return;
    setIsQuickProcessing(true);

    try {
      const res = await fetch('/api/gemini/quick-text', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: quickInput }),
      });
      const json = await res.json();
      if (res.ok && json.success) {
        setQuickResult(json.data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsQuickProcessing(false);
    }
  };

  return (
    <div className="space-y-4 pb-24">
      {/* 1. Header Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-violet-900 via-indigo-900 to-slate-900 text-white p-5 shadow-lg border border-violet-800/40 space-y-2">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-violet-600/50 flex items-center justify-center">
            <Bot size={20} className="text-violet-300" />
          </div>
          <h2 className="text-lg font-bold">Trợ Lý Tài Chính Thông Minh (AI)</h2>
        </div>
        <p className="text-xs text-violet-200/90 leading-relaxed">
          Quét bóc tách hóa đơn siêu thị, biên lai chuyển khoản ngân hàng bằng hình ảnh hoặc nhận diện câu nói tiếng Việt tự nhiên.
        </p>
      </div>

      {/* 2. Sub Tabs */}
      <div className="grid grid-cols-3 p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl gap-1">
        <button
          onClick={() => setSubTab('receipt')}
          className={`py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
            subTab === 'receipt'
              ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <Camera size={14} />
          <span>Quét Hóa Đơn</span>
        </button>
        <button
          onClick={() => setSubTab('advisor')}
          className={`py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
            subTab === 'advisor'
              ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <Sparkles size={14} />
          <span>Phân Tích 50/30/20</span>
        </button>
        <button
          onClick={() => setSubTab('quick')}
          className={`py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
            subTab === 'quick'
              ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <FileText size={14} />
          <span>Bóc Tách Văn Bản</span>
        </button>
      </div>

      {/* 3. SUBTAB 1: RECEIPT SCANNER */}
      {subTab === 'receipt' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
          <div className="text-center space-y-1">
            <h3 className="font-bold text-slate-900 dark:text-white text-base">
              Chụp Hoặc Tải Lên Ảnh Hóa Đơn
            </h3>
            <p className="text-xs text-slate-400">
              Hỗ trợ hóa đơn Co.opmart, WinMart, nhà hàng, cây xăng Petrolimex, biên lai VietinBank, VCB, MoMo...
            </p>
          </div>

          {/* Upload Area */}
          <div className="border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-2xl p-4 text-center hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
            {selectedImage ? (
              <div className="space-y-3">
                <img
                  src={selectedImage}
                  alt="Hóa đơn"
                  className="max-h-56 mx-auto rounded-xl shadow-md object-contain border border-slate-200 dark:border-slate-700"
                />
                <div className="flex justify-center gap-2">
                  <label className="px-3 py-1.5 text-xs font-semibold rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 cursor-pointer">
                    Chọn ảnh khác
                    <input type="file" accept="image/*" onChange={handleImageChange} className="hidden" />
                  </label>
                  <button
                    onClick={handleScanReceipt}
                    disabled={isScanning}
                    className="px-4 py-1.5 text-xs font-bold rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow-sm hover:from-violet-700 hover:to-indigo-700 disabled:opacity-50 flex items-center gap-1.5"
                  >
                    <Sparkles size={14} />
                    <span>{isScanning ? 'Đang đọc hóa đơn...' : 'Bắt đầu quét'}</span>
                  </button>
                </div>
              </div>
            ) : (
              <label className="cursor-pointer block py-6 space-y-2">
                <div className="w-12 h-12 rounded-full bg-violet-50 dark:bg-violet-950/60 text-violet-600 dark:text-violet-400 flex items-center justify-center mx-auto">
                  <Upload size={22} />
                </div>
                <div>
                  <p className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-200">
                    Bấm để chọn ảnh từ máy hoặc mở máy ảnh
                  </p>
                  <p className="text-[11px] text-slate-400">PNG, JPG, HEIC tối đa 15MB</p>
                </div>
                <input type="file" accept="image/*" onChange={handleImageChange} className="hidden" />
              </label>
            )}
          </div>

          {/* Error */}
          {scanError && (
            <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 text-rose-600 text-xs flex items-center gap-2">
              <AlertCircle size={16} />
              <span>{scanError}</span>
            </div>
          )}

          {/* Result Card */}
          {scanResult && (
            <div className="bg-slate-50 dark:bg-slate-850 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3 animate-in fade-in">
              <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-700">
                <div className="flex items-center gap-2">
                  <CategoryIcon catKey={scanResult.category || 'an_uong'} size="sm" />
                  <span className="font-bold text-sm text-slate-900 dark:text-white">
                    {scanResult.merchant || 'Đơn vị giao dịch'}
                  </span>
                </div>
                <span className="text-lg font-black text-rose-500 money-mask">
                  {formatVND(scanResult.amount)}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-slate-400 block">Ngày giao dịch:</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-200">
                    {scanResult.date}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block">Danh mục đề xuất:</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-200">
                    {CATEGORY_MAP[scanResult.category]?.name || 'Khác'}
                  </span>
                </div>
              </div>

              {scanResult.note && (
                <div className="text-xs">
                  <span className="text-slate-400 block">Ghi chú:</span>
                  <p className="text-slate-700 dark:text-slate-300 font-medium">{scanResult.note}</p>
                </div>
              )}

              {/* Items detail list if available */}
              {scanResult.items && scanResult.items.length > 0 && (
                <div className="pt-2 border-t border-slate-200 dark:border-slate-700">
                  <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                    Chi tiết món hàng ({scanResult.items.length})
                  </span>
                  <div className="space-y-1 max-h-36 overflow-y-auto text-xs">
                    {scanResult.items.map((item: any, idx: number) => (
                      <div key={idx} className="flex justify-between text-slate-600 dark:text-slate-300 py-0.5">
                        <span className="truncate pr-2">
                          {item.name} {item.qty ? `(x${item.qty})` : ''}
                        </span>
                        <span className="font-medium shrink-0">{formatVND(item.price)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Action save */}
              <div className="pt-2">
                {hasSavedReceipt ? (
                  <div className="w-full py-2.5 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold text-xs flex items-center justify-center gap-1.5">
                    <CheckCircle2 size={16} />
                    <span>Đã lưu vào sổ thu chi thành công!</span>
                  </div>
                ) : (
                  <button
                    onClick={handleSaveScannedReceipt}
                    className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-500/20 flex items-center justify-center gap-1.5"
                  >
                    <Plus size={16} />
                    <span>Lưu Vào Sổ Thu Chi Ngay</span>
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* 4. SUBTAB 2: FINANCIAL ADVISOR 50/30/20 */}
      {subTab === 'advisor' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base text-slate-900 dark:text-white">
                  Phân Tích Sức Khỏe Tài Chính Tháng
                </h3>
                <p className="text-xs text-slate-400">
                  AI đánh giá toàn diện thu, chi, nợ và đưa ra khuyến nghị thực tế.
                </p>
              </div>
              <button
                onClick={handleGenerateAdvice}
                disabled={isAnalyzing}
                className="px-4 py-2 bg-gradient-to-r from-violet-600 to-indigo-600 text-white text-xs font-bold rounded-xl shadow-sm hover:from-violet-700 disabled:opacity-50 flex items-center gap-1.5"
              >
                <RefreshCw size={13} className={isAnalyzing ? 'animate-spin' : ''} />
                <span>{isAnalyzing ? 'Đang phân tích...' : 'Bắt đầu đánh giá'}</span>
              </button>
            </div>

            {adviceError && (
              <div className="p-3 rounded-2xl bg-rose-50 text-rose-600 text-xs flex items-center gap-2">
                <AlertCircle size={15} />
                <span>{adviceError}</span>
              </div>
            )}
          </div>

          {/* Advice Output */}
          {adviceResult && (
            <div className="space-y-4 animate-in fade-in">
              {/* Score card */}
              <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-sm flex items-center justify-between gap-4">
                <div>
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
                    Điểm sức khỏe tài chính
                  </span>
                  <h4 className="text-2xl font-black text-slate-900 dark:text-white mt-1">
                    {adviceResult.healthStatus}
                  </h4>
                  <p className="text-xs text-slate-500 mt-1 max-w-sm">
                    {adviceResult.summary}
                  </p>
                </div>
                <div className="w-16 h-16 rounded-full bg-emerald-50 dark:bg-emerald-950/60 border-4 border-emerald-500 flex items-center justify-center font-black text-xl text-emerald-600 dark:text-emerald-400 shrink-0">
                  {adviceResult.financialHealthScore}
                </div>
              </div>

              {/* 50/30/20 Assessment */}
              {adviceResult.rule503020 && (
                <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-2">
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                    Đánh giá quy tắc 50/30/20
                  </h4>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    {adviceResult.rule503020.comment}
                  </p>
                </div>
              )}

              {/* Action recommendations */}
              {adviceResult.actionSteps && (
                <div className="space-y-2">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider px-1">
                    3 Lời khuyên hành động cụ thể
                  </span>
                  <div className="space-y-2">
                    {adviceResult.actionSteps.map((step: any, idx: number) => (
                      <div
                        key={idx}
                        className="bg-white dark:bg-slate-900 p-4 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-xs flex items-start gap-3"
                      >
                        <div className="w-7 h-7 rounded-full bg-violet-100 dark:bg-violet-950 text-violet-600 font-bold flex items-center justify-center text-xs shrink-0 mt-0.5">
                          {idx + 1}
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                            {step.title}
                          </p>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                            {step.detail}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* 5. SUBTAB 3: QUICK TEXT BÓC TÁCH */}
      {subTab === 'quick' && (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
          <div className="space-y-1">
            <h3 className="font-bold text-slate-900 dark:text-white text-base">
              Ghi Sổ Bằng Ngôn Ngữ Tự Nhiên
            </h3>
            <p className="text-xs text-slate-400">
              Gõ tự nhiên như nhắn tin: AI sẽ tự tách số tiền, danh mục, thời gian và ghi chú.
            </p>
          </div>

          <div className="space-y-2">
            <textarea
              rows={3}
              value={quickInput}
              onChange={e => setQuickInput(e.target.value)}
              placeholder="VD: Chiều nay đổ xăng 80k cây Petrolimex và mua 2 gói bánh 30k ở Winmart thanh toán MoMo"
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-3 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-violet-500/20"
            />
            <button
              onClick={handleQuickTextParse}
              disabled={isQuickProcessing || !quickInput.trim()}
              className="w-full py-2.5 bg-gradient-to-r from-violet-600 to-indigo-600 text-white text-xs font-bold rounded-xl shadow-sm hover:from-violet-700 disabled:opacity-50 flex items-center justify-center gap-1.5"
            >
              <Sparkles size={14} />
              <span>{isQuickProcessing ? 'Đang bóc tách...' : 'Phân tích & Điền giao dịch'}</span>
            </button>
          </div>

          {quickResult && (
            <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2.5">
              <div className="flex justify-between items-center">
                <span className="font-bold text-xs text-slate-500 uppercase">Kết quả AI trích xuất:</span>
                <span className="font-extrabold text-rose-500 text-base">
                  {formatVND(quickResult.amount)}
                </span>
              </div>
              <p className="text-xs font-medium text-slate-800 dark:text-slate-200">
                Ghi chú: {quickResult.note}
              </p>
              <div className="flex gap-2 text-xs text-slate-500">
                <span>Danh mục: {CATEGORY_MAP[quickResult.category]?.name || 'Khác'}</span>
                <span>•</span>
                <span>Ngày: {quickResult.date}</span>
              </div>
              <button
                onClick={() => {
                  addTransaction({
                    type: quickResult.type === 'in' ? 'in' : 'out',
                    cat: quickResult.category || 'an_uong',
                    amount: quickResult.amount || 0,
                    date: quickResult.date,
                    note: quickResult.note,
                  });
                  setQuickResult(null);
                  setQuickInput('');
                  confetti({ particleCount: 60, spread: 60, origin: { y: 0.6 } });
                }}
                className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl"
              >
                + Lưu giao dịch này
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
