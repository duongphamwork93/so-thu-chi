import React, { useMemo, useState } from 'react';
import {
  Search,
  Filter,
  Trash2,
  Calendar,
  CreditCard,
  Plus,
  ArrowDownLeft,
  ArrowUpRight,
  TrendingDown,
  TrendingUp,
} from 'lucide-react';
import { useFinance } from '../../context/FinanceContext';
import { ALL_CATEGORIES, CATEGORY_MAP } from '../../constants/categories';
import { CategoryIcon } from '../CategoryIcon';
import { formatDateVietnamese, formatVND } from '../../utils/formatters';
import { TransactionType } from '../../types/finance';

interface LedgerViewProps {
  onOpenAddModal: (type?: TransactionType) => void;
}

export const LedgerView: React.FC<LedgerViewProps> = ({ onOpenAddModal }) => {
  const { data, currentMonth, deleteTransaction } = useFinance();

  const [typeFilter, setTypeFilter] = useState<'all' | 'out' | 'in'>('all');
  const [selectedCat, setSelectedCat] = useState<string>('all');
  const [selectedAccount, setSelectedAccount] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Filter records for current month + filters
  const filteredRecords = useMemo(() => {
    return data.records.filter(r => {
      // Must match current month
      if (!r.date || !r.date.startsWith(currentMonth)) return false;

      // Filter by type
      if (typeFilter !== 'all' && r.type !== typeFilter) return false;

      // Filter by category
      if (selectedCat !== 'all' && r.cat !== selectedCat) return false;

      // Filter by account
      if (selectedAccount !== 'all' && r.accountId !== selectedAccount) return false;

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const noteMatch = (r.note || '').toLowerCase().includes(q);
        const catName = (CATEGORY_MAP[r.cat]?.name || '').toLowerCase();
        const catMatch = catName.includes(q);
        const amountMatch = String(r.amount).includes(q);
        if (!noteMatch && !catMatch && !amountMatch) return false;
      }

      return true;
    });
  }, [data.records, currentMonth, typeFilter, selectedCat, selectedAccount, searchQuery]);

  // Aggregate totals for the filtered results
  const totalFilteredOut = filteredRecords
    .filter(r => r.type === 'out')
    .reduce((sum, r) => sum + r.amount, 0);

  const totalFilteredIn = filteredRecords
    .filter(r => r.type === 'in')
    .reduce((sum, r) => sum + r.amount, 0);

  // Group records by Date descending
  const groupedByDate = useMemo(() => {
    const groups: Record<string, typeof filteredRecords> = {};
    filteredRecords.forEach(r => {
      if (!groups[r.date]) groups[r.date] = [];
      groups[r.date].push(r);
    });

    return Object.entries(groups).sort(([dateA], [dateB]) => dateB.localeCompare(dateA));
  }, [filteredRecords]);

  return (
    <div className="space-y-4 pb-24">
      {/* 1. Search & Filter Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
        {/* Search input */}
        <div className="relative">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Tìm theo ghi chú, tên quán, món ăn, số tiền..."
            className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
          />
        </div>

        {/* Segmented Type Filter */}
        <div className="grid grid-cols-3 p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl gap-1">
          <button
            onClick={() => setTypeFilter('all')}
            className={`py-1.5 text-xs font-bold rounded-xl transition-all ${
              typeFilter === 'all'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-800'
            }`}
          >
            Tất Cả ({filteredRecords.length})
          </button>
          <button
            onClick={() => setTypeFilter('out')}
            className={`py-1.5 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1 ${
              typeFilter === 'out'
                ? 'bg-rose-500 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-800'
            }`}
          >
            <ArrowDownLeft size={13} />
            <span>Chi Tiền</span>
          </button>
          <button
            onClick={() => setTypeFilter('in')}
            className={`py-1.5 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1 ${
              typeFilter === 'in'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-800'
            }`}
          >
            <ArrowUpRight size={13} />
            <span>Thu Tiền</span>
          </button>
        </div>

        {/* Secondary Filters: Category & Account */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          <select
            value={selectedCat}
            onChange={e => setSelectedCat(e.target.value)}
            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-1.5 text-slate-800 dark:text-slate-200 focus:outline-none truncate"
          >
            <option value="all">Tất cả danh mục</option>
            {ALL_CATEGORIES.map(c => (
              <option key={c.key} value={c.key}>
                {c.name}
              </option>
            ))}
          </select>

          <select
            value={selectedAccount}
            onChange={e => setSelectedAccount(e.target.value)}
            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-1.5 text-slate-800 dark:text-slate-200 focus:outline-none truncate"
          >
            <option value="all">Tất cả tài khoản/ví</option>
            {data.accts.map(a => (
              <option key={a.id} value={a.id}>
                {a.name}
              </option>
            ))}
          </select>
        </div>

        {/* Mini stats summary */}
        <div className="flex items-center justify-between pt-1 text-xs border-t border-slate-100 dark:border-slate-800 text-slate-500 font-medium">
          <div className="flex items-center gap-1">
            <span>Tổng chi:</span>
            <span className="font-bold text-rose-500 money-mask">-{formatVND(totalFilteredOut)}</span>
          </div>
          <div className="flex items-center gap-1">
            <span>Tổng thu:</span>
            <span className="font-bold text-emerald-600 dark:text-emerald-400 money-mask">
              +{formatVND(totalFilteredIn)}
            </span>
          </div>
        </div>
      </div>

      {/* 2. Grouped Transaction List */}
      {groupedByDate.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-10 border border-dashed border-slate-200 dark:border-slate-800 text-center space-y-3">
          <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">
            Không tìm thấy giao dịch nào phù hợp với bộ lọc
          </p>
          <button
            onClick={() => onOpenAddModal()}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-sm transition-colors inline-flex items-center gap-1.5"
          >
            <Plus size={15} />
            <span>Thêm giao dịch ngay</span>
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {groupedByDate.map(([dateStr, items]) => {
            const dayExpense = items
              .filter(i => i.type === 'out')
              .reduce((sum, i) => sum + i.amount, 0);
            const dayIncome = items
              .filter(i => i.type === 'in')
              .reduce((sum, i) => sum + i.amount, 0);

            return (
              <div key={dateStr} className="space-y-1.5">
                {/* Date header bar */}
                <div className="flex items-center justify-between px-2 text-xs font-semibold text-slate-500 dark:text-slate-400">
                  <div className="flex items-center gap-1.5">
                    <Calendar size={13} className="text-emerald-600" />
                    <span>{formatDateVietnamese(dateStr)}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {dayIncome > 0 && (
                      <span className="text-emerald-600 dark:text-emerald-400 money-mask">
                        +{formatVND(dayIncome)}
                      </span>
                    )}
                    {dayExpense > 0 && (
                      <span className="text-slate-700 dark:text-slate-300 money-mask">
                        -{formatVND(dayExpense)}
                      </span>
                    )}
                  </div>
                </div>

                {/* Items in date */}
                <div className="bg-white dark:bg-slate-900 rounded-3xl divide-y divide-slate-100 dark:divide-slate-800/80 border border-slate-200/80 dark:border-slate-800 shadow-sm overflow-hidden">
                  {items.map(tx => {
                    const cat = CATEGORY_MAP[tx.cat] || { name: 'Khác' };
                    const isExpense = tx.type === 'out';
                    const linkedAccount = data.accts.find(a => a.id === tx.accountId);

                    return (
                      <div
                        key={tx.id}
                        className="p-3.5 flex items-center justify-between gap-3 hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors group"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <CategoryIcon catKey={tx.cat} size="md" />
                          <div className="min-w-0">
                            <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                              {tx.note || cat.name}
                            </p>
                            <div className="flex items-center gap-1.5 text-xs text-slate-400 mt-0.5">
                              <span className="font-medium text-slate-500 dark:text-slate-400">
                                {cat.name}
                              </span>
                              {linkedAccount && (
                                <>
                                  <span>•</span>
                                  <span className="truncate max-w-[130px] font-medium text-slate-600 dark:text-slate-300">
                                    {linkedAccount.name}
                                  </span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <div className="text-right">
                            <p
                              className={`money-mask font-bold text-sm sm:text-base ${
                                isExpense
                                  ? 'text-slate-900 dark:text-white'
                                  : 'text-emerald-600 dark:text-emerald-400'
                              }`}
                            >
                              {isExpense ? '-' : '+'}
                              {formatVND(tx.amount)}
                            </p>
                          </div>

                          {/* Delete button */}
                          <button
                            onClick={() => {
                              if (confirm('Bạn có chắc muốn xóa giao dịch này?')) {
                                deleteTransaction(tx.id);
                              }
                            }}
                            className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-300 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors opacity-70 group-hover:opacity-100"
                            title="Xóa giao dịch"
                          >
                            <Trash2 size={15} />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
