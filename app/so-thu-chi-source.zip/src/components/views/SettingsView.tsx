import React, { useRef, useState } from 'react';
import {
  Download,
  Upload,
  RefreshCw,
  Eye,
  EyeOff,
  Target,
  Shield,
  CheckCircle2,
  AlertTriangle,
  Github,
  Sparkles,
  GitCommit,
  ArrowUpRight,
  Key,
  Copy,
  ExternalLink,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useFinance } from '../../context/FinanceContext';
import { parseVietnameseMoneyText } from '../../utils/formatters';

export const SettingsView: React.FC = () => {
  const {
    data,
    updateSettings,
    togglePrivacyMask,
    exportBackupJSON,
    importBackupJSON,
    resetToSampleData,
  } = useFinance();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [budgetInput, setBudgetInput] = useState<string>(
    data.settings.budget ? String(data.settings.budget) : ''
  );
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);

  // GitHub push state
  const [githubToken, setGithubToken] = useState<string>('');
  const [showToken, setShowToken] = useState<boolean>(false);
  const [commitMessage, setCommitMessage] = useState<string>(
    'Nâng cấp Sổ Thu Chi (React 19 + TypeScript + Tailwind + AI Gemini)'
  );
  const [isPushing, setIsPushing] = useState<boolean>(false);
  const [pushStatus, setPushStatus] = useState<{
    type: 'success' | 'error';
    message: string;
    details?: string;
  } | null>(null);

  const [copiedCmd, setCopiedCmd] = useState<boolean>(false);

  const handleSaveBudget = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseVietnameseMoneyText(budgetInput);
    updateSettings({ budget: val });
    setSaveSuccessMsg('Đã lưu hạn mức ngân sách thành công!');
    setTimeout(() => setSaveSuccessMsg(null), 3000);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = ev => {
      const text = ev.target?.result as string;
      const success = importBackupJSON(text);
      if (success) {
        alert('Khôi phục dữ liệu thành công!');
      } else {
        alert('File sao lưu không hợp lệ. Vui lòng kiểm tra lại file JSON!');
      }
    };
    reader.readAsText(file);
  };

  const handlePushToGithub = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!githubToken.trim()) return;

    setIsPushing(true);
    setPushStatus(null);

    try {
      const res = await fetch('/api/github/push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token: githubToken.trim(),
          repoOwner: 'duongphamwork93',
          repoName: 'so-thu-chi',
          branch: 'main',
          commitMsg: commitMessage.trim(),
        }),
      });

      const json = await res.json();
      if (!res.ok || !json.success) {
        throw new Error(json.error || 'Không thể đẩy lên GitHub');
      }

      setPushStatus({
        type: 'success',
        message: json.message,
        details: json.details,
      });

      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.6 },
      });
    } catch (err: any) {
      setPushStatus({
        type: 'error',
        message: err.message || 'Lỗi khi cập nhật lên GitHub',
      });
    } finally {
      setIsPushing(false);
    }
  };

  const manualCommands = `# 1. Tải file ZIP mã nguồn về máy và giải nén vào thư mục repo so-thu-chi
git add .
git commit -m "Nâng cấp giao diện Sổ Thu Chi (React 19 + TypeScript + Tailwind)"
git push origin main`;

  const copyManualCommands = () => {
    navigator.clipboard.writeText(manualCommands);
    setCopiedCmd(true);
    setTimeout(() => setCopiedCmd(false), 2000);
  };

  return (
    <div className="space-y-4 pb-28">
      {/* Title */}
      <div className="px-1">
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">Cài Đặt & Cập Nhật GitHub</h2>
        <p className="text-xs text-slate-400">
          Cập nhật mã nguồn lên GitHub, quản lý ngân sách, quyền riêng tư và sao lưu dữ liệu.
        </p>
      </div>

      {/* 1. GITHUB UPDATE CARD (NEW HIGHLIGHT) */}
      <div className="rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white p-5 sm:p-6 shadow-xl border border-indigo-800/40 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-white/10 flex items-center justify-center text-white border border-white/10">
              <Github size={22} />
            </div>
            <div>
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <span>Cập Nhật Lên GitHub</span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full font-semibold">
                  duongphamwork93/so-thu-chi
                </span>
              </h3>
              <p className="text-xs text-indigo-200/80">
                Đưa toàn bộ giao diện và tính năng mới vào kho lưu trữ GitHub của bạn
              </p>
            </div>
          </div>

          <a
            href="https://github.com/duongphamwork93/so-thu-chi"
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:inline-flex items-center gap-1 text-xs text-indigo-300 hover:text-white underline font-medium"
          >
            <span>Mở repo</span>
            <ExternalLink size={13} />
          </a>
        </div>

        {/* 2 One-Click Download Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
          <a
            href="/api/download/source"
            download="so-thu-chi-source.zip"
            className="p-3 rounded-2xl bg-white/10 hover:bg-white/15 border border-white/10 transition-colors flex items-center gap-3 text-left group"
          >
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <Download size={18} />
            </div>
            <div className="min-w-0">
              <p className="text-xs sm:text-sm font-bold text-white truncate">
                Tải Mã Nguồn Đầy Đủ (.ZIP)
              </p>
              <p className="text-[11px] text-indigo-200/70 truncate">
                React 19 + TypeScript + Vite + Tailwind
              </p>
            </div>
          </a>

          <a
            href="/api/download/build"
            download="so-thu-chi-github-pages.zip"
            className="p-3 rounded-2xl bg-white/10 hover:bg-white/15 border border-white/10 transition-colors flex items-center gap-3 text-left group"
          >
            <div className="w-9 h-9 rounded-xl bg-blue-500/20 text-blue-300 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <ArrowUpRight size={18} />
            </div>
            <div className="min-w-0">
              <p className="text-xs sm:text-sm font-bold text-white truncate">
                Tải Bản Tĩnh GitHub Pages (.ZIP)
              </p>
              <p className="text-[11px] text-indigo-200/70 truncate">
                Build sẵn HTML/CSS/JS chạy ngay không cần cài đặt
              </p>
            </div>
          </a>
        </div>

        {/* Option A: Direct Push via Personal Access Token */}
        <div className="bg-white/5 rounded-2xl p-4 border border-white/10 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs uppercase font-bold tracking-wider text-indigo-300 flex items-center gap-1.5">
              <Key size={14} />
              <span>Cách 1: Đẩy Trực Tiếp Lên GitHub Từ Ứng Dụng</span>
            </span>
          </div>

          <form onSubmit={handlePushToGithub} className="space-y-3">
            <div>
              <label className="text-[11px] text-indigo-200/90 block mb-1">
                GitHub Personal Access Token (PAT):
              </label>
              <div className="relative">
                <input
                  type={showToken ? 'text' : 'password'}
                  value={githubToken}
                  onChange={e => setGithubToken(e.target.value)}
                  placeholder="ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                  className="w-full bg-slate-950/70 border border-indigo-700/60 rounded-xl px-3 py-2 pr-10 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-400 font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowToken(!showToken)}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  {showToken ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
              <p className="text-[10px] text-indigo-300/70 mt-1">
                Token chỉ dùng 1 lần trong phiên để chạy lệnh git push, không lưu trữ trên máy chủ.
              </p>
            </div>

            <div>
              <label className="text-[11px] text-indigo-200/90 block mb-1">
                Thông điệp commit:
              </label>
              <input
                type="text"
                value={commitMessage}
                onChange={e => setCommitMessage(e.target.value)}
                className="w-full bg-slate-950/70 border border-indigo-700/60 rounded-xl px-3 py-2 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-400"
              />
            </div>

            <button
              type="submit"
              disabled={isPushing || !githubToken.trim()}
              className="w-full py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-500/20 disabled:opacity-50 transition-all flex items-center justify-center gap-1.5"
            >
              <GitCommit size={15} />
              <span>{isPushing ? 'Đang đóng gói & đẩy lên GitHub...' : 'Đẩy Thẳng Lên GitHub Ngay'}</span>
            </button>
          </form>

          {/* Result Status Message */}
          {pushStatus && (
            <div
              className={`p-3 rounded-xl text-xs space-y-1 ${
                pushStatus.type === 'success'
                  ? 'bg-emerald-950/80 border border-emerald-500/40 text-emerald-200'
                  : 'bg-rose-950/80 border border-rose-500/40 text-rose-200'
              }`}
            >
              <div className="flex items-center gap-1.5 font-bold">
                {pushStatus.type === 'success' ? <CheckCircle2 size={16} /> : <AlertTriangle size={16} />}
                <span>{pushStatus.message}</span>
              </div>
              {pushStatus.details && (
                <pre className="text-[10px] font-mono whitespace-pre-wrap max-h-24 overflow-y-auto bg-black/40 p-2 rounded-lg text-slate-300">
                  {pushStatus.details}
                </pre>
              )}
            </div>
          )}

          {/* Quick guide on how to get token */}
          <div className="text-[11px] text-indigo-200/70 border-t border-white/10 pt-2.5 space-y-1">
            <span className="font-semibold text-white">Cách tạo GitHub Token trong 30 giây:</span>
            <ol className="list-decimal list-inside space-y-0.5 pl-1">
              <li>Vào GitHub → <strong>Settings</strong> → <strong>Developer settings</strong> → <strong>Personal access tokens (classic)</strong>.</li>
              <li>Bấm <strong>Generate new token (classic)</strong>.</li>
              <li>Tích chọn quyền <strong className="text-emerald-400">repo</strong> (Full control of private repositories) rồi bấm <strong>Generate token</strong>.</li>
              <li>Sao chép token dán vào ô bên trên và bấm nút Đẩy lên GitHub.</li>
            </ol>
          </div>
        </div>

        {/* Option B: Manual Git Commands */}
        <div className="bg-white/5 rounded-2xl p-4 border border-white/10 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs uppercase font-bold tracking-wider text-indigo-300">
              Cách 2: Cập Nhật Bằng Dòng Lệnh Git Trên Máy
            </span>
            <button
              onClick={copyManualCommands}
              className="text-[11px] text-indigo-300 hover:text-white flex items-center gap-1 font-semibold"
            >
              <Copy size={12} />
              <span>{copiedCmd ? 'Đã sao chép!' : 'Sao chép lệnh'}</span>
            </button>
          </div>
          <pre className="text-[11px] font-mono bg-black/50 p-2.5 rounded-xl text-emerald-300 overflow-x-auto whitespace-pre-wrap">
            {manualCommands}
          </pre>
        </div>
      </div>

      {/* 2. Monthly Budget */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3">
        <div className="flex items-center gap-2">
          <Target size={18} className="text-emerald-600 dark:text-emerald-400" />
          <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white">
            Hạn Mức Ngân Sách Chi Tiêu Hàng Tháng
          </h3>
        </div>
        <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
          Ứng dụng sẽ cảnh báo khi bạn chi tiêu vượt ngưỡng này để giúp bạn tiết kiệm tốt hơn.
        </p>

        <form onSubmit={handleSaveBudget} className="flex gap-2">
          <input
            type="text"
            value={budgetInput}
            onChange={e => setBudgetInput(e.target.value)}
            placeholder="VD: 15tr, 20000000"
            className="flex-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl px-3 py-2 text-sm text-slate-900 dark:text-white focus:outline-none"
          />
          <button
            type="submit"
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-2xl shadow-sm transition-colors"
          >
            Lưu hạn mức
          </button>
        </form>

        {saveSuccessMsg && (
          <p className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
            <CheckCircle2 size={14} />
            <span>{saveSuccessMsg}</span>
          </p>
        )}
      </div>

      {/* 3. Privacy Mode Toggle */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-sm flex items-center justify-between gap-4">
        <div className="space-y-0.5 min-w-0">
          <div className="flex items-center gap-2">
            <Shield size={18} className="text-amber-500" />
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              Chế Độ Ẩn Số Tiền (Privacy Mask)
            </h3>
          </div>
          <p className="text-xs text-slate-400">
            Làm mờ tất cả các con số tiền tệ khi mở app ở nơi công cộng hoặc công ty.
          </p>
        </div>

        <button
          onClick={togglePrivacyMask}
          className={`w-12 h-7 rounded-full p-1 transition-colors ${
            data.settings.privacyMask ? 'bg-emerald-600' : 'bg-slate-200 dark:bg-slate-700'
          }`}
        >
          <div
            className={`w-5 h-5 rounded-full bg-white transition-transform ${
              data.settings.privacyMask ? 'translate-x-5' : 'translate-x-0'
            }`}
          />
        </button>
      </div>

      {/* 4. Backup & Restore (Full compatibility with sothuchi.v1) */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
        <div>
          <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white">
            Sao Lưu & Khôi Phục Dữ Liệu
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Dữ liệu được lưu trữ an toàn trong trình duyệt của bạn (khóa{' '}
            <code className="text-emerald-600 font-mono">sothuchi.v1</code>). Xuất file JSON để chuyển sang máy khác.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <button
            onClick={exportBackupJSON}
            className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 flex items-center gap-3 transition-colors text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 flex items-center justify-center shrink-0">
              <Download size={20} />
            </div>
            <div>
              <p className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">
                Xuất file sao lưu (Backup)
              </p>
              <p className="text-[11px] text-slate-400">Tải file .json về máy</p>
            </div>
          </button>

          <button
            onClick={() => fileInputRef.current?.click()}
            className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 flex items-center gap-3 transition-colors text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-950 text-blue-600 flex items-center justify-center shrink-0">
              <Upload size={20} />
            </div>
            <div>
              <p className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">
                Khôi phục từ file (Restore)
              </p>
              <p className="text-[11px] text-slate-400">Chọn file .json đã lưu</p>
            </div>
            <input
              type="file"
              ref={fileInputRef}
              accept=".json"
              onChange={handleFileSelect}
              className="hidden"
            />
          </button>
        </div>

        {/* Reset sample data */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center">
          <span className="text-xs text-slate-500">Đặt lại dữ liệu mẫu chuẩn:</span>
          <button
            onClick={() => {
              if (confirm('Bạn có muốn đặt lại toàn bộ dữ liệu mẫu ban đầu?')) {
                resetToSampleData();
              }
            }}
            className="text-xs text-rose-500 hover:underline font-semibold flex items-center gap-1"
          >
            <RefreshCw size={12} />
            <span>Nạp dữ liệu mẫu</span>
          </button>
        </div>
      </div>

      {/* 5. GitHub Project & Privacy Info */}
      <div className="bg-slate-50 dark:bg-slate-850 p-5 rounded-3xl border border-slate-200/80 dark:border-slate-800 space-y-3 text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
        <div className="flex items-center gap-2 text-slate-900 dark:text-white font-bold">
          <Github size={16} />
          <span>Dự Án Sổ Thu Chi (duongphamwork93/so-thu-chi)</span>
        </div>
        <p>
          Ứng dụng quản lý thu chi cá nhân và gia đình được thiết kế tối ưu cho cuộc sống tại Việt Nam: hỗ trợ tiền học cho con, sữa bỉm, y tế gia đình, sổ tiết kiệm ngân hàng, đầu tư tích sản và bóc tách hoá đơn thông minh bằng AI.
        </p>
        <p className="text-[11px] text-slate-400">
          Bản quyền mã nguồn mở theo giấy phép MIT. Toàn bộ dữ liệu nằm 100% trên thiết bị của bạn.
        </p>
      </div>
    </div>
  );
};
