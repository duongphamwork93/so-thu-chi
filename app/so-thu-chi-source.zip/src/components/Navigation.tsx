import React from 'react';
import { Home, ReceiptText, Plus, Landmark, Bot, Settings as SettingsIcon } from 'lucide-react';

export type TabKey = 'home' | 'ledger' | 'assets' | 'ai' | 'settings';

interface NavigationProps {
  activeTab: TabKey;
  onTabChange: (tab: TabKey) => void;
  onOpenAddModal: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({ activeTab, onTabChange, onOpenAddModal }) => {
  const tabs = [
    { key: 'home' as TabKey, label: 'Tổng quan', icon: Home },
    { key: 'ledger' as TabKey, label: 'Sổ thu chi', icon: ReceiptText },
    { key: 'assets' as TabKey, label: 'Tài sản & Nợ', icon: Landmark },
    { key: 'ai' as TabKey, label: 'Trợ lý AI', icon: Bot, isAIBadge: true },
    { key: 'settings' as TabKey, label: 'Cài đặt', icon: SettingsIcon },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 pb-[env(safe-area-inset-bottom,0px)]">
      <div className="max-w-lg mx-auto h-16 px-3 flex items-center justify-between relative">
        {/* Left 2 tabs */}
        <div className="flex-1 flex justify-around">
          {tabs.slice(0, 2).map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.key;
            return (
              <button
                key={tab.key}
                onClick={() => onTabChange(tab.key)}
                className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all duration-150 ${
                  isActive
                    ? 'text-emerald-600 dark:text-emerald-400 font-bold scale-105'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
              >
                <Icon size={21} strokeWidth={isActive ? 2.5 : 2} />
                <span className="text-[10px] mt-0.5">{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Floating Center Action Button */}
        <div className="relative -top-4 flex flex-col items-center">
          <button
            onClick={onOpenAddModal}
            className="w-14 h-14 rounded-full bg-gradient-to-tr from-emerald-600 via-teal-600 to-cyan-500 text-white flex items-center justify-center shadow-lg shadow-emerald-600/35 hover:scale-105 active:scale-95 transition-all focus:outline-none focus:ring-4 focus:ring-emerald-500/20"
            title="Thêm giao dịch mới"
          >
            <Plus size={28} strokeWidth={2.8} />
          </button>
          <span className="text-[10px] font-semibold text-emerald-700 dark:text-emerald-400 mt-0.5">
            Ghi sổ
          </span>
        </div>

        {/* Right 3 tabs */}
        <div className="flex-1 flex justify-around">
          {tabs.slice(2).map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.key;
            return (
              <button
                key={tab.key}
                onClick={() => onTabChange(tab.key)}
                className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all duration-150 relative ${
                  isActive
                    ? 'text-emerald-600 dark:text-emerald-400 font-bold scale-105'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
              >
                <div className="relative">
                  <Icon size={21} strokeWidth={isActive ? 2.5 : 2} />
                  {tab.isAIBadge && (
                    <span className="absolute -top-1 -right-2 px-1 py-0.2 bg-violet-600 text-white text-[8px] font-bold rounded-full leading-tight">
                      AI
                    </span>
                  )}
                </div>
                <span className="text-[10px] mt-0.5">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};
