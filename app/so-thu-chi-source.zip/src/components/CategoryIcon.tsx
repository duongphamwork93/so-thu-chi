import React from 'react';
import {
  Utensils,
  ShoppingCart,
  Car,
  Home,
  Baby,
  GraduationCap,
  ToyBrick,
  Stethoscope,
  HeartPulse,
  Coffee,
  ShoppingBag,
  Tv,
  Gift,
  PiggyBank,
  CreditCard,
  CircleEllipsis,
  Briefcase,
  Award,
  Laptop,
  TrendingUp,
  ShieldCheck,
  Receipt,
  Sparkles,
  Coins,
  LucideIcon,
} from 'lucide-react';
import { CATEGORY_MAP } from '../constants/categories';

const ICON_MAP: Record<string, LucideIcon> = {
  Utensils,
  ShoppingCart,
  Car,
  Home,
  Baby,
  GraduationCap,
  ToyBrick,
  Stethoscope,
  HeartPulse,
  Coffee,
  ShoppingBag,
  Tv,
  Gift,
  PiggyBank,
  CreditCard,
  CircleEllipsis,
  Briefcase,
  Award,
  Laptop,
  TrendingUp,
  ShieldCheck,
  Receipt,
  Sparkles,
  Coins,
};

interface CategoryIconProps {
  catKey: string;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  showBackground?: boolean;
}

export const CategoryIcon: React.FC<CategoryIconProps> = ({
  catKey,
  size = 'md',
  className = '',
  showBackground = true,
}) => {
  const cat = CATEGORY_MAP[catKey] || {
    name: 'Khác',
    color: '#64748B',
    iconName: 'CircleEllipsis',
  };

  const IconComponent = ICON_MAP[cat.iconName] || CircleEllipsis;

  const sizeClasses = {
    sm: 'w-7 h-7 text-xs',
    md: 'w-10 h-10 text-sm',
    lg: 'w-12 h-12 text-base',
  }[size];

  const iconSizes = {
    sm: 15,
    md: 20,
    lg: 24,
  }[size];

  if (!showBackground) {
    return <IconComponent size={iconSizes} style={{ color: cat.color }} className={className} />;
  }

  return (
    <div
      className={`rounded-2xl flex items-center justify-center shrink-0 transition-transform ${sizeClasses} ${className}`}
      style={{
        backgroundColor: `${cat.color}18`,
        color: cat.color,
      }}
      title={cat.name}
    >
      <IconComponent size={iconSizes} strokeWidth={2.2} />
    </div>
  );
};
