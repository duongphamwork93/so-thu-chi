import React from 'react';
import { ChevronLeft, ChevronRight, Eye, EyeOff, Sparkles, Wallet, Calendar, Github } from 'lucide-react';
import { useFinance } from '../context/FinanceContext';
import { calculateNetWorthBreakdown, formatVNDShort } from '../utils/formatters';

interface HeaderProps {
  onOpenQuickScan?: () => void;
  onOpenQuickAdd?: () => void;
  onOpenGitHubModal?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenQuickScan,
  onOpenQuickAdd,
  onOpenGitHubModal,
}) => {
  const { currentMonth, shiftMonth, data, togglePrivacyMask } = useFinance();
  const netWorthData = calculateNetWorthBreakdown(data);

  const [yearStr, monthStr] = currentMonth.split('-');
  const monthLabel = `Tháng ${Number(monthStr)}/${yearStr}`;

  return (
    <header className="sticky top-0 z-30 bg-white/85 dark:bg-slate-900/85 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800/80 transition-colors">
      <div className="max-w-5xl mx-auto px-4 py-2.5 flex items-center justify-between gap-3">
        {/* Brand & Net Worth preview */}
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 via-teal-600 to-cyan-500 flex items-center justify-center text-white shadow-md shadow-emerald-500/20 shrink-0">
            <Wallet className="w-5 h-5" strokeWidth={2.4} />
          </div>
          <div className="min-w-0">
            <h1 className="text-base font-bold text-slate-900 dark:text-white leading-tight truncate flex items-center gap-1.5">
              <span>Sổ Thu Chi</span>
              <span className="hidden sm:inline-block text-[11px] font-semibold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-full border border-emerald-200 dark:border-emerald-800">
                Gia đình
              </span>
            </h1>
            <div className="flex items-center gap-1 text-xs text-slate-500 dark:text-slate-400 font-medium">
              <span>Tài sản ròng:</span>
              <span className="money-mask font-semibold text-slate-800 dark:text-slate-200">
                {formatVNDShort(netWorthData.netWorth)}
              </span>
            </div>
          </div>
        </div>

        {/* Center: Month Navigator */}
        <div className="flex items-center bg-slate-100 dark:bg-slate-800 rounded-xl p-1 border border-slate-200/60 dark:border-slate-700/60 shadow-inner">
          <button
            onClick={() => shiftMonth(-1)}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-white active:scale-95 transition-all"
            title="Tháng trước"
          >
            <ChevronLeft size={18} />
          </button>
          <div className="px-3 text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-1.5 min-w-[7.5rem] justify-center">
            <Calendar size={14} className="text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span>{monthLabel}</span>
          </div>
          <button
            onClick={() => shiftMonth(1)}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-white active:scale-95 transition-all"
            title="Tháng sau"
          >
            <ChevronRight size={18} />
          </button>
        </div>

        {/* Right Actions: Privacy Mask & AI Scan */}
        <div className="flex items-center gap-2">
          <button
            onClick={togglePrivacyMask}
            className={`w-9 h-9 rounded-xl flex items-center justify-center border transition-all ${
              data.settings.privacyMask
                ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400 border-amber-300 dark:border-amber-700'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
            title={data.settings.privacyMask ? 'Đang ẩn số tiền (Bấm để hiện)' : 'Bấm để ẩn số tiền nơi công cộng'}
          >
            {data.settings.privacyMask ? <EyeOff size={18} /> : <Eye size={18} />}
          </button>

          {onOpenGitHubModal && (
            <button
              onClick={onOpenGitHubModal}
              className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-bold rounded-xl bg-slate-900 hover:bg-slate-800 text-white shadow-xs active:scale-95 transition-all"
              title="Cập nhật lên GitHub duongphamwork93/so-thu-chi"
            >
              <Github size={14} />
              <span className="hidden xs:inline">Cập nhật GitHub</span>
              <span className="xs:hidden">GitHub</span>
            </button>
          )}

          {onOpenQuickScan && (
            <button
              onClick={onOpenQuickScan}
              className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white shadow-sm shadow-indigo-500/25 active:scale-95 transition-all"
            >
              <Sparkles size={14} />
              <span>Quét AI</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
